-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 16, 2026 at 10:51 AM
-- Server version: 12.0.2-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `noted`
--

-- --------------------------------------------------------

--
-- Table structure for table `colleges`
--

CREATE TABLE `colleges` (
  `college_id` int(11) NOT NULL,
  `college_name` varchar(150) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `created_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_by` int(11) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `colleges`
--

INSERT INTO `colleges` (`college_id`, `college_name`, `created_at`, `created_by`, `updated_at`, `updated_by`, `deleted_at`, `deleted_by`) VALUES
(1, 'Engineering', '2026-03-06 10:39:10', NULL, '2026-03-06 10:39:10', NULL, NULL, NULL),
(2, 'Natural Science', '2026-03-06 10:39:10', NULL, '2026-03-06 10:39:10', NULL, NULL, NULL),
(3, 'Business', '2026-03-06 10:39:10', NULL, '2026-03-06 10:39:10', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `department_id` int(11) NOT NULL,
  `college_id` int(11) NOT NULL,
  `department_name` varchar(150) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `created_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_by` int(11) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`department_id`, `college_id`, `department_name`, `created_at`, `created_by`, `updated_at`, `updated_by`, `deleted_at`, `deleted_by`) VALUES
(1, 1, 'Computer Science', '2026-03-06 10:39:10', NULL, '2026-03-06 10:39:10', NULL, NULL, NULL),
(2, 1, 'Information Technology', '2026-03-06 10:39:10', NULL, '2026-03-06 10:39:10', NULL, NULL, NULL),
(3, 2, 'Biology', '2026-03-06 10:39:10', NULL, '2026-03-06 10:39:10', NULL, NULL, NULL),
(4, 3, 'Accounting', '2026-03-06 10:39:10', NULL, '2026-03-06 10:39:10', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `directorates`
--

CREATE TABLE `directorates` (
  `directorate_id` int(11) NOT NULL,
  `college_id` int(11) NOT NULL,
  `directorate_name` varchar(150) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `created_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_by` int(11) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `log_history`
--

CREATE TABLE `log_history` (
  `log_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `action_type` varchar(50) NOT NULL,
  `action_description` text DEFAULT NULL,
  `table_name` varchar(100) DEFAULT NULL,
  `record_id` int(11) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `browser_info` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `log_history`
--

INSERT INTO `log_history` (`log_id`, `user_id`, `action_type`, `action_description`, `table_name`, `record_id`, `ip_address`, `browser_info`, `created_at`) VALUES
(6, 1, 'LOGIN', 'User logged in', 'users', 1, '127.0.0.1', 'Chrome', '2026-03-06 10:53:27'),
(7, 2, 'INSERT', 'New user created', 'users', 2, '127.0.0.1', 'Firefox', '2026-03-06 10:53:27'),
(8, 3, 'UPDATE', 'User profile updated', 'users', 3, '127.0.0.1', 'Edge', '2026-03-06 10:53:27'),
(9, 4, 'DELETE', 'User removed', 'users', 4, '127.0.0.1', 'Chrome', '2026-03-06 10:53:27'),
(10, 5, 'VIEW', 'Viewed dashboard', 'menu_items', 29, '127.0.0.1', 'Chrome', '2026-03-06 10:53:27'),
(11, 6, 'INSERT', 'User created : johndoe', 'users', 6, NULL, NULL, '2026-03-06 10:57:15'),
(12, 7, 'INSERT', 'User created : alicesmith', 'users', 7, NULL, NULL, '2026-03-06 10:57:15'),
(13, 8, 'INSERT', 'User created : bobbrown', 'users', 8, NULL, NULL, '2026-03-06 10:57:15'),
(14, 0, 'FAILED_LOGIN', 'Invalid password attempt for username: johndoe', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-06 11:38:54'),
(15, 0, 'FAILED_LOGIN', 'Invalid password attempt for username: johndoe', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-06 11:39:10'),
(16, 0, 'FAILED_LOGIN', 'Invalid password attempt for username: johndoe', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-06 11:39:15'),
(17, 0, 'FAILED_LOGIN', 'Invalid password attempt for username: johndoe', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-06 11:40:18'),
(18, 11, 'LOGIN', 'User logged in successfully with migrated password.', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-06 11:41:53'),
(19, 11, 'LOGIN', 'User logged in successfully.', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-06 11:50:49'),
(20, 11, 'LOGIN', 'User logged in successfully.', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-06 12:00:41'),
(21, 11, 'LOGIN', 'User logged in successfully.', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-06 12:02:00'),
(22, 11, 'LOGIN', 'User logged in successfully.', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-06 12:04:51'),
(23, 11, 'LOGIN', 'User logged in successfully.', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-06 12:05:10'),
(24, 0, 'FAILED_LOGIN', 'Unknown username attempted: j', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-06 12:07:52'),
(25, 11, 'LOGIN', 'User logged in successfully.', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-06 12:08:18'),
(26, 11, 'LOGIN', 'User logged in successfully.', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-06 12:09:00'),
(27, 11, 'LOGIN', 'User logged in successfully.', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-06 12:10:45'),
(28, 11, 'LOGIN', 'User logged in successfully.', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-06 12:15:17'),
(29, 11, 'LOGIN', 'User logged in successfully.', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-06 12:17:40'),
(30, 11, 'LOGIN', 'User logged in successfully.', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-06 12:19:39'),
(31, 11, 'LOGIN', 'User logged in successfully.', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-06 12:24:28'),
(32, 11, 'LOGIN', 'User logged in successfully.', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-06 12:26:01'),
(33, 11, 'LOGIN', 'User logged in successfully.', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-06 12:26:12'),
(34, 11, 'LOGIN', 'User logged in successfully.', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-06 12:27:24'),
(35, 11, 'LOGIN', 'User logged in successfully.', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-06 12:32:24'),
(36, 11, 'LOGIN', 'User logged in successfully.', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-06 12:58:45'),
(37, NULL, 'Menu Save', 'Updated menu ID 36', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-06 12:59:46'),
(38, NULL, 'Menu Save', 'Updated menu ID 36', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-06 12:59:54'),
(39, 11, 'LOGIN', 'User logged in successfully.', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-06 13:18:56'),
(40, 11, 'LOGIN', 'User logged in successfully.', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-06 13:29:05'),
(41, 0, 'FAILED_LOGIN', 'Unknown username attempted: Aku02332', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 11:15:19'),
(42, 11, 'LOGIN', 'User logged in successfully.', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 11:15:26'),
(43, 11, 'LOGIN', 'User logged in successfully.', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 11:30:49'),
(44, 9, 'INSERT', 'User created : hjk', 'users', 9, NULL, NULL, '2026-03-07 11:31:34'),
(45, 10, 'INSERT', 'User created : fdgdfg', 'users', 10, NULL, NULL, '2026-03-07 11:35:07'),
(46, 11, 'INSERT', 'User created : dfgdf', 'users', 11, NULL, NULL, '2026-03-07 11:36:41'),
(47, 13, 'INSERT', 'User created : dfgdfg', 'users', 13, NULL, NULL, '2026-03-07 11:40:52'),
(48, 16, 'INSERT', 'User created : ghfghgfhgfhfgh', 'users', 16, NULL, NULL, '2026-03-07 11:42:54'),
(49, 11, 'LOGIN', 'User logged in successfully.', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 11:54:10'),
(50, 20, 'INSERT', 'User created : khjkhj', 'users', 20, NULL, NULL, '2026-03-07 11:55:15'),
(51, NULL, 'Save User', 'Added new user khjkhj', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 11:55:15'),
(52, NULL, 'Save User', 'Updated user ID 20', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 11:55:34'),
(53, NULL, 'Delete User', 'Deleted user ID 11', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 12:13:05'),
(54, NULL, 'Delete User', 'Deleted user ID 13', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 12:13:12'),
(55, NULL, 'Delete User', 'Deleted user ID 10', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 12:13:19'),
(56, NULL, 'Delete User', 'Deleted user ID 16', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 12:13:25'),
(57, NULL, 'Delete User', 'Deleted user ID 9', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 12:13:33'),
(58, 0, 'FAILED_LOGIN', 'Unknown username attempted: aku02332', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 12:14:11'),
(59, 11, 'LOGIN', 'User logged in successfully.', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 12:19:47'),
(60, 0, 'FAILED_LOGIN', 'Unknown username attempted: j', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 12:19:52'),
(61, 11, 'LOGIN', 'User logged in successfully.', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 12:19:59'),
(62, 11, 'LOGIN', 'User logged in successfully.', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 12:29:38'),
(63, 11, 'LOGIN', 'User logged in successfully.', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 12:39:23'),
(64, NULL, 'Save User', 'Updated user ID 6', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 12:49:04'),
(65, NULL, 'Save User', 'Updated user ID 8', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 12:49:16'),
(66, NULL, 'Menu Delete', 'Deleted menu ID 16', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 12:58:38'),
(67, NULL, 'Menu Delete', 'Deleted menu ID 7', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 12:58:57'),
(68, NULL, 'Menu Delete', 'Deleted menu ID 49', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 12:59:02'),
(69, NULL, 'Menu Delete', 'Deleted menu ID 13', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 12:59:07'),
(70, NULL, 'Menu Delete', 'Deleted menu ID 6', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 12:59:14'),
(71, NULL, 'Menu Delete', 'Deleted menu ID 3', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 12:59:17'),
(72, NULL, 'Menu Delete', 'Deleted menu ID 48', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 12:59:21'),
(73, NULL, 'Menu Delete', 'Deleted menu ID 9', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 12:59:26'),
(74, NULL, 'Menu Delete', 'Deleted menu ID 47', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 12:59:36'),
(75, NULL, 'Menu Delete', 'Deleted menu ID 29', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 12:59:41'),
(76, NULL, 'Menu Delete', 'Deleted menu ID 2', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 12:59:58'),
(77, NULL, 'Menu Delete', 'Deleted menu ID 31', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 13:00:12'),
(78, NULL, 'Menu Delete', 'Deleted menu ID 50', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 13:00:22'),
(79, NULL, 'Menu Delete', 'Deleted menu ID 46', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 13:00:28'),
(80, NULL, 'Menu Save', 'Updated menu ID 44', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 13:01:01'),
(81, NULL, 'Menu Save', 'Added new menu \'Men Managment\'', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 13:03:22'),
(82, NULL, 'Menu Save', 'Updated menu ID 27', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 13:03:54'),
(83, NULL, 'Menu Save', 'Updated menu ID 51', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 13:04:07'),
(84, NULL, 'Menu Save', 'Updated menu ID 32', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 13:04:20'),
(85, NULL, 'Menu Save', 'Updated menu ID 30', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 13:04:33'),
(86, NULL, 'Menu Save', 'Updated menu ID 19', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 13:04:40'),
(87, NULL, 'Menu Save', 'Updated menu ID 22', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 13:05:01'),
(88, NULL, 'Menu Save', 'Updated menu ID 30', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 13:05:12'),
(89, NULL, 'Menu Save', 'Updated menu ID 36', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 13:07:49'),
(90, NULL, 'Menu Save', 'Updated menu ID 32', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 13:08:18'),
(91, NULL, 'Menu Save', 'Updated menu ID 33', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 13:08:41'),
(92, NULL, 'Menu Save', 'Updated menu ID 30', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 13:09:14'),
(93, NULL, 'Menu Save', 'Updated menu ID 27', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 13:09:46'),
(94, NULL, 'Menu Save', 'Updated menu ID 22', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 13:10:05'),
(95, NULL, 'Menu Save', 'Updated menu ID 51', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 13:10:49'),
(96, NULL, 'Menu Save', 'Updated menu ID 44', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 13:11:08'),
(97, NULL, 'Menu Save', 'Updated menu ID 19', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 13:11:37'),
(98, NULL, 'Menu Save', 'Updated menu ID 15', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 13:12:58'),
(99, NULL, 'Menu Save', 'Updated menu ID 51', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 13:13:48'),
(100, NULL, 'Menu Save', 'Updated menu ID 15', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-07 13:14:10'),
(101, 11, 'LOGIN', 'User logged in successfully.', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-12 11:25:26'),
(102, 0, 'FAILED_LOGIN', 'Unknown username attempted: j', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-12 11:26:53'),
(103, 11, 'LOGIN', 'User logged in successfully.', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-12 11:27:39'),
(104, 11, 'LOGIN', 'User logged in successfully.', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-12 11:30:34'),
(105, 11, 'LOGIN', 'User logged in successfully.', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-12 14:50:28'),
(106, NULL, 'Menu Save', 'Updated menu ID 22', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-12 14:55:03'),
(107, NULL, 'Menu Save', 'Updated menu ID 30', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-12 14:55:34'),
(108, NULL, 'Menu Save', 'Updated menu ID 27', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-12 14:55:49'),
(109, NULL, 'Menu Save', 'Updated menu ID 33', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-12 14:55:59'),
(110, NULL, 'Menu Save', 'Updated menu ID 36', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-12 14:56:21'),
(111, NULL, 'Menu Save', 'Updated menu ID 33', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-12 14:56:31'),
(112, NULL, 'Menu Save', 'Updated menu ID 32', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-12 14:56:43'),
(113, NULL, 'Menu Save', 'Updated menu ID 30', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-12 14:56:52'),
(114, 11, 'LOGIN', 'User logged in successfully.', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-12 15:09:24'),
(115, 11, 'LOGIN', 'User logged in successfully.', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36', '2026-03-12 15:27:08'),
(116, 11, 'LOGIN', 'User logged in successfully.', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-15 08:52:53'),
(117, 11, 'LOGIN', 'User logged in successfully.', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-15 09:16:18'),
(118, 11, 'LOGIN', 'User logged in successfully.', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-15 14:29:00'),
(119, NULL, 'Menu Save', 'Added new menu \'Profile\'', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-15 14:30:03'),
(120, 11, 'LOGIN', 'User logged in successfully.', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-15 14:39:35'),
(121, 11, 'LOGIN', 'User logged in successfully.', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-15 14:41:10'),
(122, 11, 'LOGIN', 'User logged in successfully.', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-15 15:00:09'),
(123, 11, 'LOGIN', 'User logged in successfully.', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-15 15:02:15'),
(124, 11, 'LOGIN', 'User logged in successfully.', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-16 08:57:43'),
(125, 11, 'LOGIN', 'User logged in successfully.', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-16 09:05:38'),
(126, NULL, 'Menu Save', 'Added new menu \'xxx\'', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-16 09:09:48'),
(127, NULL, 'Menu Save', 'Updated menu ID 53', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-16 09:11:48'),
(128, NULL, 'Menu Save', 'Updated menu ID 53', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-16 09:12:16'),
(129, NULL, 'Menu Save', 'Updated menu ID 30', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-16 09:25:21'),
(130, 11, 'LOGIN', 'User logged in successfully.', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-16 09:25:29'),
(131, NULL, 'Menu Save', 'Updated menu ID 30', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-16 09:25:36'),
(132, 12, 'LOGIN', 'User logged in successfully.', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-16 09:36:55'),
(133, 11, 'LOGIN', 'User logged in successfully.', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-16 09:40:28'),
(134, NULL, 'Menu Save', 'Updated menu ID 44', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-16 09:40:40'),
(135, NULL, 'Menu Save', 'Updated menu ID 52', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-16 09:40:57'),
(136, NULL, 'Menu Save', 'Updated menu ID 53', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-16 09:41:13'),
(137, 12, 'LOGIN', 'User logged in successfully.', NULL, NULL, '10.189.22.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36', '2026-03-16 09:44:01');

-- --------------------------------------------------------

--
-- Table structure for table `menu_items`
--

CREATE TABLE `menu_items` (
  `menu_id` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `title` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `url` varchar(255) DEFAULT '#',
  `icon_class` varchar(100) DEFAULT NULL,
  `icon_color` varchar(50) DEFAULT NULL,
  `link_color` varchar(50) DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0,
  `is_common` tinyint(1) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `created_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_by` int(11) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `menu_items`
--

INSERT INTO `menu_items` (`menu_id`, `parent_id`, `title`, `description`, `url`, `icon_class`, `icon_color`, `link_color`, `sort_order`, `is_common`, `created_at`, `created_by`, `updated_at`, `updated_by`, `deleted_at`, `deleted_by`) VALUES
(15, NULL, 'Role Lists', '', 'role.php', 'ace-icon fa fa-list-ol', 'text-info', 'text-grey', 3, 0, '2026-01-06 09:56:50', NULL, '2026-03-07 13:14:10', NULL, NULL, NULL),
(19, NULL, 'Log History', '', 'loghistory.php?categ=all', 'ace-icon fa fa-history', 'text-danger', 'text-info', 4, 0, '2026-01-06 09:56:50', NULL, '2026-03-07 13:11:37', NULL, NULL, NULL),
(22, NULL, 'Today', '', 'calander.php', 'ace-icon fa fa-calculator', 'text-danger', 'text-success', 5, 0, '2026-01-06 10:17:44', NULL, '2026-03-12 14:55:03', NULL, NULL, NULL),
(27, NULL, 'Login', '', 'login.php', 'ace-icon fa fa-lock', 'text-danger', 'text-warning', 6, 0, '2026-01-06 10:19:14', NULL, '2026-03-12 14:55:49', NULL, NULL, NULL),
(30, NULL, 'Mission & Vision', '', 'Vision.php', 'ace-icon fa fa-pie-chart', 'text-info', 'text-warning', 10, 1, '2026-01-06 10:22:00', NULL, '2026-03-16 09:25:36', NULL, NULL, NULL),
(32, NULL, 'Help', '', 'help.php', 'ace-icon fa fa-bar-chart', 'text-info', 'text-pink', 9, 1, '2026-01-06 10:22:00', NULL, '2026-03-12 14:56:43', NULL, NULL, NULL),
(33, NULL, 'Developer', '', 'developer_inf.php', 'ace-icon fa fa-delicious', 'text-info', 'text-danger', 8, 1, '2026-01-06 10:22:00', NULL, '2026-03-12 14:56:31', NULL, NULL, NULL),
(36, NULL, 'Help Disk', '', '#', 'ace-icon fa fa-heart', 'text-info', 'text-warning', 7, 1, '2026-01-10 08:07:29', NULL, '2026-03-12 14:56:21', NULL, NULL, NULL),
(44, NULL, 'Dashboard', 'index for CURR', 'index.php', 'ace-icon fa fa-dashboard', 'text-info', 'text-success', 1, 1, '2026-01-25 05:44:54', NULL, '2026-03-16 09:40:40', NULL, NULL, NULL),
(51, NULL, 'Men Managment', 'menu_managment lists', 'menu_managment.php', 'ace-icon fa fa-list-ul', 'text-info', 'text-primary', 2, 1, '2026-03-07 13:03:22', NULL, '2026-03-07 13:13:48', NULL, NULL, NULL),
(52, NULL, 'Profile', 'Users Profile detail', 'profile.php', 'ace-icon fa fa-user-md', 'text-primary', 'text-purple', 3, 0, '2026-03-15 14:30:03', NULL, '2026-03-16 09:40:57', NULL, NULL, NULL),
(53, NULL, 'xxx', 'xcbxcbxcb', 'vbvbnvb.php', 'ace-icon fa fa-chevron-down', 'text-danger', 'text-success', 13, 0, '2026-03-16 09:09:48', NULL, '2026-03-16 09:41:13', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `officers`
--

CREATE TABLE `officers` (
  `officer_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `directorate_id` int(11) NOT NULL,
  `position_title` varchar(100) DEFAULT NULL,
  `office_phone` varchar(25) DEFAULT NULL,
  `status` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `created_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_by` int(11) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `role_id` int(11) NOT NULL,
  `role_name` varchar(100) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `status` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `created_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_by` int(11) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`role_id`, `role_name`, `description`, `status`, `created_at`, `created_by`, `updated_at`, `updated_by`, `deleted_at`, `deleted_by`) VALUES
(1, 'ADMIN', 'administrator', 1, '2026-03-06 10:39:10', NULL, '2026-03-06 10:39:10', NULL, NULL, NULL),
(2, 'INSTRUCTOR', 'Teacher', 1, '2026-03-06 10:39:10', NULL, '2026-03-06 10:39:10', NULL, NULL, NULL),
(3, 'STUDENT', 'Student', 1, '2026-03-06 10:39:10', NULL, '2026-03-06 10:39:10', NULL, NULL, NULL),
(4, 'OFFICER', 'Directorate Officer', 1, '2026-03-06 10:39:10', NULL, '2026-03-06 10:39:10', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `role_data`
--

CREATE TABLE `role_data` (
  `rid` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `role_name` varchar(200) NOT NULL,
  `description` varchar(500) NOT NULL,
  `record_by` varchar(20) NOT NULL,
  `record_date` datetime NOT NULL DEFAULT current_timestamp(),
  `record_updated_by` varchar(20) NOT NULL,
  `record_updated_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `role_data`
--

INSERT INTO `role_data` (`rid`, `role_id`, `status`, `role_name`, `description`, `record_by`, `record_date`, `record_updated_by`, `record_updated_date`) VALUES
(1, 1, 1, 'Admin', 'Admin', 'aku02332', '2026-03-07 15:54:41', 'aku02332', '2026-03-16 12:10:59'),
(45, 3, 1, 'Student', 'Student', 'aku02332', '2026-03-16 12:31:45', 'aku02332', '2026-03-16 12:36:32');

-- --------------------------------------------------------

--
-- Table structure for table `role_menu_access`
--

CREATE TABLE `role_menu_access` (
  `role_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `created_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_by` int(11) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `role_menu_access`
--

INSERT INTO `role_menu_access` (`role_id`, `menu_id`, `created_at`, `created_by`, `updated_at`, `updated_by`, `deleted_at`, `deleted_by`) VALUES
(1, 15, '2026-03-16 09:10:59', NULL, '2026-03-16 09:10:59', NULL, NULL, NULL),
(1, 19, '2026-03-16 09:10:59', NULL, '2026-03-16 09:10:59', NULL, NULL, NULL),
(1, 22, '2026-03-16 09:10:59', NULL, '2026-03-16 09:10:59', NULL, NULL, NULL),
(1, 27, '2026-03-16 09:10:59', NULL, '2026-03-16 09:10:59', NULL, NULL, NULL),
(1, 30, '2026-03-16 09:10:59', NULL, '2026-03-16 09:10:59', NULL, NULL, NULL),
(1, 32, '2026-03-16 09:10:59', NULL, '2026-03-16 09:10:59', NULL, NULL, NULL),
(1, 33, '2026-03-16 09:10:59', NULL, '2026-03-16 09:10:59', NULL, NULL, NULL),
(1, 36, '2026-03-16 09:10:59', NULL, '2026-03-16 09:10:59', NULL, NULL, NULL),
(1, 44, '2026-03-16 09:10:59', NULL, '2026-03-16 09:10:59', NULL, NULL, NULL),
(1, 51, '2026-03-16 09:10:59', NULL, '2026-03-16 09:10:59', NULL, NULL, NULL),
(1, 52, '2026-03-16 09:10:59', NULL, '2026-03-16 09:10:59', NULL, NULL, NULL),
(1, 53, '2026-03-16 09:10:59', NULL, '2026-03-16 09:10:59', NULL, NULL, NULL),
(3, 19, '2026-03-16 09:34:49', NULL, '2026-03-16 09:34:49', NULL, NULL, NULL),
(3, 30, '2026-03-16 09:34:49', NULL, '2026-03-16 09:34:49', NULL, NULL, NULL),
(3, 33, '2026-03-16 09:34:49', NULL, '2026-03-16 09:34:49', NULL, NULL, NULL),
(3, 44, '2026-03-16 09:34:49', NULL, '2026-03-16 09:34:49', NULL, NULL, NULL),
(3, 52, '2026-03-16 09:34:49', NULL, '2026-03-16 09:34:49', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `university_structure`
--

CREATE TABLE `university_structure` (
  `id` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `type` enum('Admin','Academic','Student','Role') NOT NULL,
  `linked_table` varchar(50) DEFAULT NULL,
  `linked_id` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Dumping data for table `university_structure`
--

INSERT INTO `university_structure` (`id`, `parent_id`, `name`, `type`, `linked_table`, `linked_id`, `description`, `created_at`) VALUES
(1, NULL, 'Admin', 'Admin', NULL, NULL, 'Administrative Users', '2026-03-06 11:12:49'),
(2, NULL, 'Academic', 'Academic', NULL, NULL, 'Colleges and Departments', '2026-03-06 11:12:49'),
(3, NULL, 'Student', 'Student', NULL, NULL, 'Student Union', '2026-03-06 11:12:49'),
(4, 1, 'Executive', 'Role', NULL, NULL, 'Executive Admin', '2026-03-06 11:12:49'),
(5, 1, 'Team Leader', 'Role', NULL, NULL, 'Team Leader Admin', '2026-03-06 11:12:49'),
(6, 1, 'Supportive', 'Role', NULL, NULL, 'Support Staff', '2026-03-06 11:12:49'),
(7, 2, 'Engineering College', 'Role', 'colleges', 1, 'College of Engineering', '2026-03-06 11:12:49'),
(8, 2, 'Business College', 'Role', 'colleges', 3, 'College of Business', '2026-03-06 11:12:49'),
(9, 5, 'Computer Science Dept', 'Role', 'departments', 1, NULL, '2026-03-06 11:12:49'),
(10, 5, 'Information Tech Dept', 'Role', 'departments', 2, NULL, '2026-03-06 11:12:49'),
(11, 6, 'Finance Directorate', 'Role', 'directorates', 2, NULL, '2026-03-06 11:12:49'),
(12, 8, 'Officer', 'Role', 'officers', NULL, NULL, '2026-03-06 11:12:49'),
(13, 3, 'Student Union', 'Role', NULL, NULL, NULL, '2026-03-06 11:12:49'),
(14, 12, 'President', 'Role', NULL, NULL, NULL, '2026-03-06 11:12:49');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `father_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `gender` enum('MALE','FEMALE') NOT NULL,
  `department_id` int(11) DEFAULT NULL,
  `role` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(120) DEFAULT NULL,
  `phone_number` varchar(25) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `created_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_by` int(11) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `first_name`, `father_name`, `last_name`, `gender`, `department_id`, `role`, `username`, `email`, `phone_number`, `created_at`, `created_by`, `updated_at`, `updated_by`, `deleted_at`, `deleted_by`) VALUES
(6, 'JOHN', 'MICHAEL', 'DOE', 'FEMALE', 1, 1, 'aku02332', 'john@example.com', '1234567890', '2026-03-06 10:57:15', NULL, '2026-03-12 11:30:26', NULL, NULL, NULL),
(8, 'Tsegay', 'Gebru', 'Asefa', 'MALE', 2, 3, 'fghfh', 'fghfg@gmail.com', '08089089', '2026-03-06 10:57:15', NULL, '2026-03-16 09:30:06', NULL, NULL, NULL);

--
-- Triggers `users`
--
DELIMITER $$
CREATE TRIGGER `trg_user_insert_audit` AFTER INSERT ON `users` FOR EACH ROW BEGIN

INSERT INTO log_history
(user_id,action_type,action_description,table_name,record_id)
VALUES
(NEW.user_id,'INSERT',
CONCAT('User created : ',NEW.username),
'users',
NEW.user_id);

END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trg_user_validate_before_insert` BEFORE INSERT ON `users` FOR EACH ROW BEGIN

SET NEW.first_name = UPPER(NEW.first_name);
SET NEW.father_name = UPPER(NEW.father_name);
SET NEW.last_name = UPPER(NEW.last_name);

IF NEW.gender NOT IN ('MALE','FEMALE') THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT='Invalid gender value';
END IF;

END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `users_login`
--

CREATE TABLE `users_login` (
  `login_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `created_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_by` int(11) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users_login`
--

INSERT INTO `users_login` (`login_id`, `user_id`, `username`, `password`, `created_at`, `created_by`, `updated_at`, `updated_by`, `deleted_at`, `deleted_by`) VALUES
(11, 6, 'aku02332', 'cfd12eeebcb496aef149a34b4ab28c8f', '2026-03-06 11:18:03', NULL, '2026-03-12 11:27:39', NULL, NULL, NULL),
(12, 8, 'aku1603519', '284396da99dc28661d180fd1b10b55a6', '2026-03-07 12:21:30', NULL, '2026-03-16 09:36:55', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_roles`
--

CREATE TABLE `user_roles` (
  `user_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `created_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_by` int(11) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_roles`
--

INSERT INTO `user_roles` (`user_id`, `role_id`, `created_at`, `created_by`, `updated_at`, `updated_by`, `deleted_at`, `deleted_by`) VALUES
(6, 1, '2026-03-07 12:49:04', NULL, '2026-03-12 11:28:52', NULL, NULL, NULL),
(8, 3, '2026-03-16 09:35:46', NULL, '2026-03-16 09:35:46', NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `colleges`
--
ALTER TABLE `colleges`
  ADD PRIMARY KEY (`college_id`),
  ADD UNIQUE KEY `college_name` (`college_name`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`department_id`),
  ADD UNIQUE KEY `college_id` (`college_id`,`department_name`);

--
-- Indexes for table `directorates`
--
ALTER TABLE `directorates`
  ADD PRIMARY KEY (`directorate_id`);

--
-- Indexes for table `log_history`
--
ALTER TABLE `log_history`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `menu_items`
--
ALTER TABLE `menu_items`
  ADD PRIMARY KEY (`menu_id`),
  ADD KEY `fk_menu_parent` (`parent_id`);

--
-- Indexes for table `officers`
--
ALTER TABLE `officers`
  ADD PRIMARY KEY (`officer_id`),
  ADD UNIQUE KEY `user_id` (`user_id`),
  ADD KEY `fk_officer_directorate` (`directorate_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`role_id`),
  ADD UNIQUE KEY `role_name` (`role_name`);

--
-- Indexes for table `role_data`
--
ALTER TABLE `role_data`
  ADD PRIMARY KEY (`rid`);

--
-- Indexes for table `role_menu_access`
--
ALTER TABLE `role_menu_access`
  ADD PRIMARY KEY (`role_id`,`menu_id`),
  ADD KEY `fk_rma_menu` (`menu_id`);

--
-- Indexes for table `university_structure`
--
ALTER TABLE `university_structure`
  ADD PRIMARY KEY (`id`),
  ADD KEY `parent_id` (`parent_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `role` (`role`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `fk_user_department` (`department_id`);

--
-- Indexes for table `users_login`
--
ALTER TABLE `users_login`
  ADD PRIMARY KEY (`login_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `fk_login_user` (`user_id`);

--
-- Indexes for table `user_roles`
--
ALTER TABLE `user_roles`
  ADD PRIMARY KEY (`user_id`,`role_id`),
  ADD KEY `fk_user_role_role` (`role_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `colleges`
--
ALTER TABLE `colleges`
  MODIFY `college_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `department_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `directorates`
--
ALTER TABLE `directorates`
  MODIFY `directorate_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `log_history`
--
ALTER TABLE `log_history`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=138;

--
-- AUTO_INCREMENT for table `menu_items`
--
ALTER TABLE `menu_items`
  MODIFY `menu_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `officers`
--
ALTER TABLE `officers`
  MODIFY `officer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `role_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `role_data`
--
ALTER TABLE `role_data`
  MODIFY `rid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `university_structure`
--
ALTER TABLE `university_structure`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `users_login`
--
ALTER TABLE `users_login`
  MODIFY `login_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `departments`
--
ALTER TABLE `departments`
  ADD CONSTRAINT `fk_department_college` FOREIGN KEY (`college_id`) REFERENCES `colleges` (`college_id`) ON DELETE CASCADE;

--
-- Constraints for table `directorates`
--
ALTER TABLE `directorates`
  ADD CONSTRAINT `fk_directorate_college` FOREIGN KEY (`college_id`) REFERENCES `colleges` (`college_id`) ON DELETE CASCADE;

--
-- Constraints for table `menu_items`
--
ALTER TABLE `menu_items`
  ADD CONSTRAINT `fk_menu_parent` FOREIGN KEY (`parent_id`) REFERENCES `menu_items` (`menu_id`) ON DELETE CASCADE;

--
-- Constraints for table `officers`
--
ALTER TABLE `officers`
  ADD CONSTRAINT `fk_officer_directorate` FOREIGN KEY (`directorate_id`) REFERENCES `directorates` (`directorate_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_officer_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `role_menu_access`
--
ALTER TABLE `role_menu_access`
  ADD CONSTRAINT `fk_rma_menu` FOREIGN KEY (`menu_id`) REFERENCES `menu_items` (`menu_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_rma_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE;

--
-- Constraints for table `university_structure`
--
ALTER TABLE `university_structure`
  ADD CONSTRAINT `university_structure_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `university_structure` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `fk_user_department` FOREIGN KEY (`department_id`) REFERENCES `departments` (`department_id`) ON DELETE SET NULL;

--
-- Constraints for table `users_login`
--
ALTER TABLE `users_login`
  ADD CONSTRAINT `fk_login_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `user_roles`
--
ALTER TABLE `user_roles`
  ADD CONSTRAINT `fk_user_role_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_user_role_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
