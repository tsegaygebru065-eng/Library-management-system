<?php
// get_departments.php
$servername = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "user_profile_db";

$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$college_id = intval($_POST['college_id'] ?? 0);
$selected_department = intval($_POST['selected_department'] ?? 0);

echo '<option value="">Select Department</option>';

if ($college_id) {
    $stmt = $conn->prepare("SELECT id, name FROM departments WHERE college_id=? ORDER BY name");
    $stmt->bind_param("i", $college_id);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) {
        $selected = ($row['id'] == $selected_department) ? 'selected' : '';
        echo "<option value='{$row['id']}' $selected>" . htmlspecialchars($row['name']) . "</option>";
    }
    $stmt->close();
}

$conn->close();