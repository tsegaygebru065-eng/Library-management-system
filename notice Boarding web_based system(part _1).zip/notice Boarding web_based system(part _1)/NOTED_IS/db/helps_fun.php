<?php
if (!function_exists('addLog')) {
    function addLog($conn, $userId, $actionType, $description) {
        $ip = $_SERVER['REMOTE_ADDR'] ?? null;
        $browser = $_SERVER['HTTP_USER_AGENT'] ?? null;

        $stmt = $conn->prepare(
            "INSERT INTO log_history (user_id, action_type, action_description, ip_address, browser_info)
             VALUES (?, ?, ?, ?, ?)"
        );
        $stmt->bind_param("issss", $userId, $actionType, $description, $ip, $browser);
        $stmt->execute();
        $stmt->close();
    }
}
