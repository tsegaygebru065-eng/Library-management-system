<?php
// Secret key — change this to your own random string!
define('CERT_SECRET_KEY', 'YourSuperSecretKey@AksumUniv2025!');

function encryptSN($sn) {
    $cipher = "AES-256-CBC";
    $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length($cipher));
    $encrypted = openssl_encrypt($sn, $cipher, CERT_SECRET_KEY, 0, $iv);
    // Combine IV + encrypted data, make URL-safe
    $token = base64_encode($iv . '::' . $encrypted);
    return urlencode($token);
}

function decryptSN($token) {
    $cipher = "AES-256-CBC";
    $data = base64_decode(urldecode($token));
    $parts = explode('::', $data, 2);
    if (count($parts) !== 2) return false;
    [$iv, $encrypted] = $parts;
    $decrypted = openssl_decrypt($encrypted, $cipher, CERT_SECRET_KEY, 0, $iv);
    return $decrypted !== false ? (int)$decrypted : false;
}
?>