<?php
$conn = mysqli_connect("localhost", "root", "", "noted");
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

?>