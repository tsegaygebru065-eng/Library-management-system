<?php
require_once __DIR__ . '/db/dbcon.php';
require_once __DIR__ . '/db/helps_fun.php';

session_start();
$error = "";

// Secret salt
define('PASSWORD_SALT', '123!');  

// Redirect if already logged in
if (!empty($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
    // If already logged in, redirect to index or session expired page
    header("Location: index.php?session=active");
    exit();
}

// Function to map role name to dashboard (optional)
function getDashboardByRole($roleName) {
    $role = strtolower($roleName);

    switch ($role) {
        case 'admin':
            return 'index.php';
        case 'team leader':
            return 'index.php';
        case 'supportive':
            return 'index.php';
        case 'officer':
            return 'index.php';
        case 'student':
            return 'index.php';
        default:
            return 'login.php';
    }
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if ($username !== '' && $password !== '') {

        // Fetch login + role
        $query = "
            SELECT ul.login_id, ul.user_id, ul.username, ul.password, r.role_name, r.role_id
            FROM users_login ul
            INNER JOIN user_roles ur ON ul.user_id = ur.user_id
            INNER JOIN roles r ON ur.role_id = r.role_id
            WHERE ul.username = ?
            LIMIT 1
        ";
        $stmt = $conn->prepare($query);

        if ($stmt) {
            $stmt->bind_param("s", $username);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result && $result->num_rows === 1) {
                $row = $result->fetch_assoc();

                // Check salted MD5 password, fallback to old plain MD5
                if (md5(PASSWORD_SALT . $password) === $row['password'] ||
                    md5($password) === $row['password']) {

                    // Migrate old MD5 password
                    if (md5($password) === $row['password']) {
                        $newHash = md5(PASSWORD_SALT . $password);
                        $updateStmt = $conn->prepare("UPDATE users_login SET password = ? WHERE login_id = ?");
                        $updateStmt->bind_param("si", $newHash, $row['login_id']);
                        $updateStmt->execute();
                        $updateStmt->close();
                    }

                    // Set session variables
                    session_regenerate_id(true);
                    $_SESSION['loggedin'] = true;
                    $_SESSION['login_id'] = $row['login_id'];
                    $_SESSION['user_id']  = $row['user_id'];
                    $_SESSION['username'] = $row['username'];
                    $_SESSION['role_name'] = strtolower($row['role_name']);
                    $_SESSION['role_id'] = $row['role_id'];

                    addLog($conn, $row['login_id'], 'LOGIN', 'User logged in successfully.');

                    // Redirect based on role
                    header("Location: " . getDashboardByRole($_SESSION['role_name']));
                    exit();
                } else {
                    $error = "Invalid username or password.";
                    addLog($conn, 0, 'FAILED_LOGIN', "Invalid password attempt for username: $username");
                }
            } else {
                $error = "Invalid username or password.";
                addLog($conn, 0, 'FAILED_LOGIN', "Unknown username attempted: $username");
            }

            $stmt->close();
        } else {
            $error = "Database error: " . $conn->error;
            addLog($conn, 0, 'FAILED_LOGIN', "Database error for username: $username");
        }

    } else {
        $error = "Please fill in both fields.";
        addLog($conn, 0, 'FAILED_LOGIN', "Empty username or password attempt.");
    }
}
?>

<?php include('includes/header.php'); ?>
<?php include('includes/admin_sidemenu.php'); ?>

<br><br><br>
<div class="login-container">
    <div class="widget-box widget-color-blue2">
        <div class="widget-header widget-header-small">
            <h4 class="widget-title lighter">
                <i class="ace-icon fa fa-lock"></i>
                Login to Your Account
            </h4>
        </div>

        <div class="widget-body">
            <div class="widget-main">
                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger">
                        <i class="fa fa-exclamation-triangle"></i> 
                        <?= htmlspecialchars($error) ?>
                    </div>
                <?php endif; ?>

                <form method="POST" action="">
                    <fieldset>
                        <label class="block clearfix">
                            <span class="block input-icon input-icon-right">
                                <input type="text" name="username" class="form-control" placeholder="Username" required autofocus />
                                <i class="ace-icon fa fa-user"></i>
                            </span>
                        </label>

                        <label class="block clearfix">
                            <span class="block input-icon input-icon-right">
                                <input type="password" name="password" class="form-control" placeholder="Password" required />
                                <i class="ace-icon fa fa-lock"></i>
                            </span>
                        </label>

                        <div class="space"></div>

                        <button type="submit" class="width-100 btn btn-sm btn-primary">
                            <i class="ace-icon fa fa-key"></i>
                            <span class="bigger-110">Login</span>
                        </button>
                    </fieldset>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include('includes/footer.php'); ?>