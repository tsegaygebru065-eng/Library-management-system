<?php
include('db/dbcon.php'); // Your DB connection, assumes $conn

// --- FUNCTION DEFINITIONS ---

function addLog($conn, $user_id_session, $action, $description) {
    $stmt = $conn->prepare("INSERT INTO log_history (user_id, action_type, action_description, created_at) VALUES (?, ?, ?, NOW())");
    $stmt->bind_param("iss", $user_id_session, $action, $description);
    $stmt->execute();
    $stmt->close();
}

function certificateRecordExists($conn, $firstName, $fatherName, $gFatherName, $department, $studentID) {
    $stmt = $conn->prepare("SELECT SN FROM certificate_records WHERE FirstName=? AND FatherName=? AND GFatherName=? AND Department=? AND StudentID=?");
    $stmt->bind_param("sssss", $firstName, $fatherName, $gFatherName, $department, $studentID);
    $stmt->execute();
    $stmt->store_result();
    $exists = $stmt->num_rows > 0;
    $stmt->close();
    return $exists;
}

function getImportTypeID($conn, $importTypeCode) {
    $stmt = $conn->prepare("SELECT ImportTypeID FROM Import_Type WHERE ImportTypeCode = ?");
    $stmt->bind_param("s", $importTypeCode);
    $stmt->execute();
    $stmt->bind_result($importTypeID);
    if ($stmt->fetch()) {
        $stmt->close();
        return $importTypeID;
    } else {
        $stmt->close();
        return null;
    }
}

$message = '';
$user_id_session = 1; // example admin user id

// === HANDLE DELETE FIRST BEFORE ANY OUTPUT ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['deleteRecord']) && isset($_POST['sn'])) {
    $sn = intval($_POST['sn']);
    $stmt = $conn->prepare("DELETE FROM certificate_records WHERE SN=?");
    $stmt->bind_param("i", $sn);
    if ($stmt->execute()) {
        addLog($conn, $user_id_session, 'DELETE_CERTIFICATE', "Deleted certificate record SN $sn");
        $stmt->close();
        header("Location: certificate_records.php?msg=deleted");
        exit; // stop script here after redirect
    } else {
        $message = "<div class='alert alert-danger'>Error deleting certificate record: " . $conn->error . "</div>";
    }
}

// Handle adding a single record
if (isset($_POST['addRecord'])) {
    $faculty       = strtoupper(trim($_POST['faculty']));
    $department    = strtoupper(trim($_POST['department']));
    $batch         = strtoupper(trim($_POST['batch']));
    $semester      = strtoupper(trim($_POST['semester']));
    $studentID     = strtoupper(trim($_POST['student_id']));
    $firstName     = strtoupper(trim($_POST['first_name']));
    $fatherName    = strtoupper(trim($_POST['father_name']));
    $gFatherName   = strtoupper(trim($_POST['gfather_name']));
    $sex           = strtoupper(trim($_POST['sex']));
    $program       = trim($_POST['program']);
    $admission     = trim($_POST['admission']);
    $remark        = trim($_POST['remark']) ?: null;
    $section       = strtoupper(trim($_POST['section']));
    $importTypeCode= strtoupper(trim($_POST['import_type']));
    $status        = trim($_POST['status']) ?: null;
    $certified     = isset($_POST['certified']) && $_POST['certified'] == '1' ? 1 : 0;
    $createdBy     = 'admin';

    if (certificateRecordExists($conn, $firstName, $fatherName, $gFatherName, $department, $studentID)) {
        $message = "<div class='alert alert-warning'>Certificate record for <b>$firstName $fatherName $gFatherName</b> with StudentID <b>$studentID</b> in department <b>$department</b> already exists.</div>";
    } else {
        $importTypeID = getImportTypeID($conn, $importTypeCode);
        if ($importTypeID === null) {
            $message = "<div class='alert alert-danger'>Import type code <b>$importTypeCode</b> not found.</div>";
        } else {
            $stmt = $conn->prepare("INSERT INTO certificate_records 
                (Faculty, Department, Batch, Semester, StudentID,
                 FirstName, FatherName, GFatherName, Sex, Program, Admission,
                 Remark, Section, ImportTypeID, Status, Certified, CreatedBy)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("sssssssssssssssis", 
                $faculty, $department, $batch, $semester, $studentID,
                $firstName, $fatherName, $gFatherName, $sex, $program, $admission,
                $remark, $section, $importTypeID, $status, $certified, $createdBy);

            if ($stmt->execute()) {
                $sn = $stmt->insert_id;
                $stmt->close();
                addLog($conn, $user_id_session, 'INSERT_CERTIFICATE', "Inserted certificate record SN $sn for $firstName $fatherName $gFatherName");
                $message = "<div class='alert alert-success'>Certificate record added successfully.</div>";
            } else {
                $message = "<div class='alert alert-danger'>Error adding certificate record: " . $conn->error . "</div>";
            }
        }
    }
}

// Handle CSV import
if (isset($_POST['importCSV']) && isset($_FILES['csv_file'])) {
    $fileName = $_FILES['csv_file']['tmp_name'];
    $duplicates = [];
    $added = 0;

    if ($_FILES['csv_file']['size'] > 0) {
        $file = fopen($fileName, "r");
        $row = 0;
        while (($column = fgetcsv($file, 1000, ",")) !== FALSE) {
            if ($row == 0) { $row++; continue; } // skip header

            $faculty       = strtoupper(trim($column[0]));
            $department    = strtoupper(trim($column[1]));
            $batch         = strtoupper(trim($column[2]));
            $semester      = strtoupper(trim($column[3]));
            $studentID     = strtoupper(trim($column[4]));

            $firstName     = strtoupper(trim($column[5]));
            $fatherName    = strtoupper(trim($column[6]));
            $gFatherName   = strtoupper(trim($column[7]));
            $sex           = strtoupper(trim($column[8]));
            $program       = trim($column[9]);
            $admission     = trim($column[10]);
            $remark        = trim($column[11]) ?: null;
            $section       = strtoupper(trim($column[12]));
            $importTypeCode= strtoupper(trim($column[13]));
            $status        = trim($column[14]) ?: null;
            $certified     = strtolower(trim($column[15])) === 'true' || trim($column[15]) === '1' ? 1 : 0;
            $createdBy     = 'admin';

            if (certificateRecordExists($conn, $firstName, $fatherName, $gFatherName, $department, $studentID)) {
                $duplicates[] = "$firstName $fatherName $gFatherName (StudentID: $studentID)";
                $row++;
                continue;
            }

            $importTypeID = getImportTypeID($conn, $importTypeCode);
            if ($importTypeID === null) {
                $row++;
                continue; // Skip invalid import type
            }

            $stmt = $conn->prepare("INSERT INTO certificate_records 
                (Faculty, Department, Batch, Semester, StudentID,
                 FirstName, FatherName, GFatherName, Sex, Program, Admission,
                 Remark, Section, ImportTypeID, Status, Certified, CreatedBy)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("sssssssssssssssis", 
                $faculty, $department, $batch, $semester, $studentID,
                $firstName, $fatherName, $gFatherName, $sex, $program, $admission,
                $remark, $section, $importTypeID, $status, $certified, $createdBy);
            $stmt->execute();
            $sn = $stmt->insert_id;
            $stmt->close();

            addLog($conn, $user_id_session, 'IMPORT_CSV_CERTIFICATE', "Imported certificate record SN $sn for $firstName $fatherName $gFatherName");
            $added++;
            $row++;
        }
        fclose($file);

        $message = "<div class='alert alert-success'>$added certificate records imported successfully.</div>";
        if (count($duplicates) > 0) {
            $message .= "<div class='alert alert-warning'>Duplicate records ignored: <b>" . implode(", ", $duplicates) . "</b></div>";
        }
    } else {
        $message = "<div class='alert alert-danger'>No file selected or file empty.</div>";
    }
}

// --- NOW INCLUDE HEADER and OUTPUT HTML ---
include('includes/header.php');

$importTypes = [];
$sql = "SELECT ImportTypeCode FROM Import_Type ORDER BY ImportTypeCode ASC";
$result = $conn->query($sql);
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $importTypes[] = $row['ImportTypeCode'];
    }
}
?>
 

<div class="main-container ace-save-state" id="main-container">
<?php include('includes/admin_sidemenu.php'); ?>
    <div class="main-content">
        <div class="main-content-inner">
            <div class="page-content">
                <div class="row">
                    <div class="col-xs-12">
                        <?php if($message != '') echo $message; ?>

                        <h3 class="header smaller lighter blue">Certificate Records List</h3>
 

<!-- ACE ADMIN WIDGET -->
  

    <div class="widget-body">
        <div class="widget-main">

            <div class="table-responsive">
            <table id="teacherTable" class="table table-striped table-bordered table-hover nowrap" style="width:100%">
    <thead>
        <tr>
            <th class="center">#</th>
            <th hidden>SN</th>
            <th>Student ID</th>
            <th>Full Name</th>
            <th class="center">Sex</th>
            <th class="center">Section</th>
            <th class="center">Status</th>
            <th class="center">Certified</th>
        </tr>
    </thead>

    <tbody>
    <?php
    $i = 0;
    $sql = "
        SELECT cr.SN, cr.Department, cr.StudentID,
               cr.FirstName, cr.FatherName, cr.GFatherName,
               cr.Sex, cr.Section, cr.Remark, cr.Status, cr.Certified
        FROM certificate_records cr
    ";

    $result = $conn->query($sql);

    while ($row = $result->fetch_assoc()) {
        $i++;
        $sn = (int)$row['SN'];

        $fullName = htmlspecialchars(
            $row['FirstName'].' '.$row['FatherName'].' '.$row['GFatherName']
        );

        $remark = trim($row['Remark']);
        $isPresented = (strcasecmp($remark, 'Absent') !== 0);

        $statusLabel = $isPresented
            ? "<span class='label label-success'>Presented</span>"
            : "<span class='label label-danger'>Absent</span>";

        $certifiedBadge = $row['Certified'];
		($certifiedBadge=="Presented")
		? "<span class='label label-success'>Yes</span>"
            : "<span class='label label-warning'>No</span>";
        ?>
        <tr>
            <td class="center"><?= $i ?></td>
            <td hidden><?= $sn ?></td>
            <td><?= htmlspecialchars($row['StudentID']) ?></td>
            <td><?= $fullName ?></td>
            <td class="center"><?= htmlspecialchars($row['Sex']) ?></td>
            <td class="center"><?= htmlspecialchars($row['Section']) ?></td>
            <td class="center"><?= $statusLabel ?></td>
            <td class="center">
                <?= $certifiedBadge ?>

                <?php if ($isPresented) { ?>
                    <button class="btn btn-xs btn-success"
                        onclick="openGenerateModal(<?= $sn ?>)">
                        <i class="ace-icon fa fa-file-pdf-o"></i>
                    </button>
                <?php }else {} ?>
            </td>
        </tr>
    <?php } ?>
    </tbody>
</table>

        </div>
    </div>
 

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Add Certificate Record Modal -->
<div id="addModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="addModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <form method="post" id="addRecordForm" autocomplete="off">
      <div class="modal-content">
        <div class="modal-header bg-primary text-white">
          <h5 class="modal-title" id="addModalLabel"><i class="fa fa-plus"></i> Add Certificate Record</h5>
          <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">&times;</button>
        </div>
        <div class="modal-body">
          <!-- Form inputs -->
          <div class="row">
            <div class="col-md-4">
              <div class="form-group">
                <label for="first_name">First Name <span class="text-danger">*</span></label>
                <input type="text" name="first_name" id="first_name" class="form-control" required>
              </div>
              <div class="form-group">
                <label for="father_name">Father Name <span class="text-danger">*</span></label>
                <input type="text" name="father_name" id="father_name" class="form-control" required>
              </div>
              <div class="form-group">
                <label for="gfather_name">Grandfather Name <span class="text-danger">*</span></label>
                <input type="text" name="gfather_name" id="gfather_name" class="form-control" required>
              </div>
              <div class="form-group">
                <label for="sex">Sex</label>
                <input type="text" name="sex" id="sex" class="form-control" maxlength="10" placeholder="M/F">
              </div>
              <div class="form-group">
                <label for="student_id">Student ID <span class="text-danger">*</span></label>
                <input type="text" name="student_id" id="student_id" class="form-control" required>
              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <label for="faculty">Faculty <span class="text-danger">*</span></label>
                <input type="text" name="faculty" id="faculty" class="form-control" required>
              </div>
              <div class="form-group">
                <label for="department">Department <span class="text-danger">*</span></label>
                <input type="text" name="department" id="department" class="form-control" required>
              </div>
              <div class="form-group">
                <label for="program">Program</label>
                <input type="text" name="program" id="program" class="form-control">
              </div>
              <div class="form-group">
                <label for="batch">Batch</label>
                <input type="text" name="batch" id="batch" class="form-control">
              </div>
              <div class="form-group">
                <label for="semester">Semester</label>
                <input type="text" name="semester" id="semester" class="form-control">
              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                 <label for="admission">Admission</label>
                 <select name="admission" id="admission" class="form-control" required>
                    <option value="">-- Select Admission Type --</option>
                    <option value="Regular">Regular</option>
                    <option value="Extension">Extension</option>
                    <option value="Evening">Evening</option>
                    <option value="Distance">Distance</option>
                 </select>
              </div>
              <div class="form-group">
                <label for="section">Section <span class="text-danger">*</span></label>
                <input type="text" name="section" id="section" class="form-control" maxlength="1" required>
              </div>
              <div class="form-group">
    <label for="import_type">Import Type Code <span class="text-danger">*</span></label>
    <select name="import_type" id="import_type" class="form-control" required>
        <option value="">-- Select Import Type --</option>
        <?php foreach ($importTypes as $code): ?>
            <option value="<?php echo htmlspecialchars($code); ?>"><?php echo htmlspecialchars($code); ?></option>
        <?php endforeach; ?>
    </select>
</div>

              
			  <div class="form-group">
            <label>Status</label>
            <select name="status" id="status" class="form-control" required>
              <option value="Presented">Presented</option>
              <option value="Absent">Absent</option>
            </select>
          </div>
              <div class="form-group">
                <label for="certified">Certified</label>
                <select name="certified" id="certified" class="form-control">
                  <option value="0" selected>No</option>
                  <option value="1">Yes</option>
                </select>
              </div>
              <div class="form-group">
                <label for="remark">Remark</label>
                <textarea name="remark" id="remark" class="form-control" rows="2" placeholder="Optional"></textarea>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" name="addRecord" class="btn btn-primary"><i class="fa fa-plus"></i> Add Record</button>
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
        </div>
      </div>
    </form>
  </div>
</div>

<!-- Import CSV Modal -->
<div id="importCSVModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="importCSVModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <form method="post" enctype="multipart/form-data" id="importCSVForm">
      <div class="modal-content">
        <div class="modal-header bg-primary text-white">
          <h5 class="modal-title" id="importCSVModalLabel"><i class="fa fa-upload"></i> Import Certificate Records CSV</h5>
          <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">&times;</button>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label for="csv_file">Select CSV file</label>
            <input type="file" name="csv_file" id="csv_file" accept=".csv" required>
            <small class="form-text text-muted">CSV must have headers: Faculty,Department,Batch,Semester,StudentID,FirstName,FatherName,GFatherName,Sex,Program,Admission,Remark,Section,ImportTypeCode,Status,Certified</small>
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" name="importCSV" class="btn btn-primary"><i class="fa fa-upload"></i> Import CSV</button>
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
        </div>
      </div>
    </form>
  </div>
</div>


<div id="editModal" class="modal fade">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header bg-info">
        <h4 class="modal-title">
            <i class="ace-icon fa fa-pencil"></i> Edit Certificate
        </h4>
      </div>
      <div class="modal-body">
        <iframe id="editFrame" style="width:100%;height:400px;border:0"></iframe>
      </div>
      <div class="modal-footer">
        <button class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>


<div id="deleteModal" class="modal fade">
  <div class="modal-dialog">
    <form method="post">
      <div class="modal-content">
        <div class="modal-header bg-danger">
          <h4 class="modal-title">
            <i class="ace-icon fa fa-trash"></i> Confirm Delete
          </h4>
        </div>
        <div class="modal-body">
          <input type="hidden" name="sn" id="deleteSN">
          <p class="text-danger">
            Are you sure you want to delete this record?
          </p>
        </div>
        <div class="modal-footer">
          <button type="submit" name="deleteRecord" class="btn btn-danger">
            Yes, Delete
          </button>
          <button type="button" class="btn btn-default" data-dismiss="modal">
            Cancel
          </button>
        </div>
      </div>
    </form>
  </div>
</div>

<div id="remarkModal" class="modal fade">
  <div class="modal-dialog">
    <form method="post" id="remarkForm">
      <div class="modal-content">
        
        <div class="modal-header bg-info">
          <h4 class="modal-title">
            <i class="ace-icon fa fa-edit"></i> Edit Remark
          </h4>
        </div>

        <div class="modal-body">
          <input type="hidden" name="sn" id="remarkSN">

          <div class="form-group">
            <label>Remark</label>
            <select name="remark" id="remarkValue" class="form-control" required>
              <option value="Presented">Presented</option>
              <option value="Absent">Absent</option>
            </select>
          </div>
        </div>

        <div class="modal-footer">
          <button type="submit" name="updateRemark" class="btn btn-success">
            <i class="ace-icon fa fa-save"></i> Save
          </button>
          <button type="button" class="btn btn-default" data-dismiss="modal">
            Cancel
          </button>
        </div>

      </div>
    </form>
  </div>
</div>


<div id="generateModal" class="modal fade">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header bg-success">
        <h4 class="modal-title">
            <i class="ace-icon fa fa-file-pdf-o"></i> Certificate Preview
        </h4>
      </div>
      <div class="modal-body">
        <iframe id="generateFrame"
                style="width:100%;height:450px;border:0"></iframe>
      </div>
      <div class="modal-footer">
        <button class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>


<script>
function openEditModal(sn) {
    $('#editFrame').attr('src', 'edit_certificate.php?sn=' + sn);
    $('#editModal').modal('show');
}

function openDeleteModal(sn) {
    $('#deleteSN').val(sn);
    $('#deleteModal').modal('show');
}

function openGenerateModal(sn) {
    $('#generateFrame').attr('src', 'generate_certificate.php?sn=' + sn);
    $('#generateModal').modal('show');
}
function openRemarkModal(sn, remark) {
    $('#remarkSN').val(sn);
    $('#remarkValue').val(remark === 'Absent' ? 'Absent' : 'Presented');
    $('#remarkModal').modal('show');
}
jQuery(function($){
    $('#certificateTable').DataTable({
        pageLength: 25,
        responsive: true,
        order: [[0,'desc']],
        lengthMenu: [[10,25,50,-1],[10,25,50,"All"]],
        language: {
            search: "Search Records:"
        }
    });
});

</script>



<?php include('includes/footer.php'); ?>
