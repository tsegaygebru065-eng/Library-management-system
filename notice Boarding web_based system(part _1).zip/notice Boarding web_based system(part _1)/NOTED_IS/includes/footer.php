<div class="modal fade" id="logoutModal">

<div class="modal-dialog modal-sm">

<div class="modal-content">

<div class="modal-header bg-danger text-white">
<h4 class="modal-title">Confirm Logout</h4>
</div>

<div class="modal-body">
Are you sure you want to logout?
</div>

<div class="modal-footer">
<button class="btn btn-default" data-dismiss="modal">Cancel</button>
<a href="logout.php" class="btn btn-danger">Logout</a>
</div>

</div>

</div>

</div>
<!-- Footer -->
<footer class="footer text-center">
    <div class="footer-inner">
        &copy; <?php echo date('Y'); ?> Aksum University. All rights reserved.
    </div>
</footer>

<!-- JS Scripts -->
<script src="assets/js/jquery-2.1.4.min.js"></script>
<script>
    if ('ontouchstart' in document.documentElement)
        document.write("<script src='assets/js/jquery.mobile.custom.min.js'><\/script>");
</script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/jquery.colorbox.min.js"></script>
<script src="assets/js/ace-elements.min.js"></script>
<script src="assets/js/ace.min.js"></script>
 
<script>
jQuery(function($){
    var table = $('#teacherTable').DataTable({ 
        responsive: true,
        scrollX: true,
        order: [[0, "desc"]],
        columnDefs: [{ orderable: false, targets: -1 }], // Disable sorting on last column (Certificate)
        dom: "<'row'<'col-sm-6'l><'col-sm-6'f>>" +
             "<'row'<'col-sm-12'tr>>" +
             "<'row'<'col-sm-5'i><'col-sm-7'p>>" +
             "B",
        buttons: [
          { extend: 'copy', className: 'btn btn-sm btn-info' },
          { extend: 'csv', className: 'btn btn-sm btn-success' },
          { extend: 'excel', className: 'btn btn-sm btn-warning' },
          { extend: 'pdf', className: 'btn btn-sm btn-primary' },
          { extend: 'print', className: 'btn btn-sm btn-default' }
        ],
        pageLength: 10, // default rows per page
        lengthMenu: [[10, 25, 50, 100, 1000], [10, 25, 50, 100, "1000"]] // custom dropdown
    });
});
</script>

<!-- Ace Admin scripts -->
<script src="assets/js/ace-elements.min.js"></script>
<script src="assets/js/ace.min.js"></script>

<!-- DataTables JS -->
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.print.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.5.0/js/dataTables.responsive.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js"></script>

</body>
</html>