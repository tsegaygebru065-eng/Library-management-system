<?php 
include('db/dbcon.php');

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ================= SESSION TIMEOUT HANDLING ==================
$timeout_duration = 300; // 5 minutes for example

if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY']) > $timeout_duration) {
    session_unset();
    session_destroy();
    header("Location: login.php?session=expired");
    exit();
}
$_SESSION['LAST_ACTIVITY'] = time();

// =============================================================

$isLoggedIn = $_SESSION['loggedin'] ?? false;
$username   = $_SESSION['username'] ?? '';
$role       = $_SESSION['role'] ?? '';
$first_name = $_SESSION['first_name'] ?? '';
$father_name= $_SESSION['father_name'] ?? '';
$last_name  = $_SESSION['last_name'] ?? '';
$full_name  = trim("$first_name $father_name $last_name") ?: $username;

$isAdmin = ($role === 'admin');

if ($isAdmin) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}
?>
<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="utf-8">
<title>Aksum University Notes Board</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="shortcut icon" href="logo/akulogo.png">

<!-- ACE CSS -->
<link rel="stylesheet" href="assets/css/bootstrap.min.css">
<link rel="stylesheet" href="assets/font-awesome/4.5.0/css/font-awesome.min.css">
<link rel="stylesheet" href="assets/css/ace.min.css">
<link rel="stylesheet" href="assets/css/ace-skins.min.css">
<link rel="stylesheet" href="assets/css/ace-rtl.min.css">

<script src="assets/js/ace-extra.min.js"></script>

<style>

.smart-header{
display:flex;
align-items:center;
justify-content:space-between;
background:#0D47A1;
color:white;
padding:15px 20px;
}

.logo-section img{
width:65px;
height:65px;
border-radius:50%;
}

.text-section{
text-align:center;
flex:1;
}

.text-section h1{
margin:0;
font-size:20px;
font-weight:bold;
}

.year{
font-size:14px;
font-weight:bold;
}

.carousel-inner > .item > img{
width:100%;
height:420px;
object-fit:cover;
}

</style>

</head>

<body class="no-skin">

<!-- HEADER -->

<div class="smart-header">

<div class="logo-section">
<img src="logo/akulogo.png">
</div>

<div class="text-section">
<h1>Aksum University Notes Board</h1>
<h1>የአክሱም ዩኒቨርሲቲ ማስታወሻ ቦርድ</h1>
</div>

<div class="year" id="date-time"></div>

</div>

<!-- NAVBAR -->

<div id="navbar" class="navbar navbar-default ace-save-state">

<div class="navbar-container ace-save-state">

<div class="navbar-header pull-left">

<a href="index.php" class="navbar-brand">
<i class="fa fa-home"></i> Home
</a>

</div>

<div class="navbar-buttons navbar-header pull-right">

<ul class="nav ace-nav">

<?php if ($isLoggedIn): ?>

<li class="light-blue dropdown">

<a data-toggle="dropdown" href="#" class="dropdown-toggle">

<img class="nav-user-photo" src="assets/images/avatars/user.jpg">

<span class="user-info">
<small>Welcome,</small>
<?= htmlspecialchars($full_name) ?>
</span>

<i class="ace-icon fa fa-caret-down"></i>

</a>

<ul class="user-menu dropdown-menu dropdown-menu-right dropdown-yellow dropdown-caret dropdown-close">

<li>
<a href="profile.php">
<i class="ace-icon fa fa-user"></i>
Profile
</a>
</li>

<li class="divider"></li>

<li>
<a href="#" data-toggle="modal" data-target="#logoutModal">
<i class="ace-icon fa fa-power-off"></i>
Logout
</a>
</li>

</ul>

</li>

<?php else: ?>

<li>
<a href="login.php">
<i class="ace-icon fa fa-lock"></i>
Login
</a>
</li>

<?php endif; ?>

</ul>

</div>

</div>

</div>


<!-- LOGOUT MODAL -->

<div class="modal fade" id="logoutModal">

<div class="modal-dialog modal-sm">

<div class="modal-content">

<div class="modal-header bg-danger text-white">
<h4 class="modal-title">Confirm Logout</h4>
</div>

<div class="modal-body">
Are you sure you want to logout?
</div>

<div class="modal-footer">

<button class="btn btn-default" data-dismiss="modal">Cancel</button>

<a href="logout.php" class="btn btn-danger">Logout</a>

</div>

</div>

</div>

</div>


<!-- ================= Scripts ================= -->
<script>
// Slideshow
let slides = document.querySelectorAll('.slide');
let currentSlide = 0;
setInterval(() => {
    slides[currentSlide].classList.remove('active');
    currentSlide = (currentSlide + 1) % slides.length;
    slides[currentSlide].classList.add('active');
}, 3000);

// Date & Time
function updateDateTime() {
    const dt = new Date();
    document.getElementById('date-time').innerText = dt.toLocaleString();
}
setInterval(updateDateTime, 1000);
updateDateTime();
</script>
 