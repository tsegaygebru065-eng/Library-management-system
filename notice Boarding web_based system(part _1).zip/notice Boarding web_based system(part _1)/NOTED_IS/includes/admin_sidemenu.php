<?php 
// Start session and DB connection
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include('db/dbcon.php');

// Current user's role_id from session (default guest = 10)
$userRoleId = $_SESSION['role_id'] ?? 10;
//echo $userRoleId;
// Fetch all menu items accessible to the user role
$sql = "
   SELECT mi.menu_id, mi.parent_id, mi.title, mi.url, mi.icon_class, mi.icon_color, mi.link_color
   FROM menu_items mi
   INNER JOIN role_menu_access rma 
       ON rma.menu_id = mi.menu_id
   WHERE rma.role_id = ?
   AND mi.deleted_at IS NULL
   ORDER BY mi.parent_id, mi.sort_order, mi.title
";

$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $userRoleId);
$stmt->execute();
$result = $stmt->get_result();

$menus = [];
while ($row = $result->fetch_assoc()) {
    $menus[] = $row;
}
$stmt->close();

// Build menu tree recursively
function buildMenuTree(array $elements, $parentId = null) {
    $branch = [];
    foreach ($elements as $element) {
        if ((int)$element['parent_id'] === (int)$parentId) {
            $children = buildMenuTree($elements, $element['menu_id']);
            $element['children'] = $children;
            $branch[] = $element;
        }
    }
    return $branch;
}

$menuTree = buildMenuTree($menus);

// Render menu HTML recursively
function renderMenu(array $menuTree) {
    echo '<ul class="nav nav-list">';
    foreach ($menuTree as $item) {
        $hasChildren = count($item['children']) > 0;

        // Escape output safely
        $iconClass = htmlspecialchars($item['icon_class']);
        $iconColorClass = htmlspecialchars($item['icon_color']);
        $linkColorClass = htmlspecialchars($item['link_color']);
        $title = htmlspecialchars($item['title']);
        $url = htmlspecialchars($item['url'] ?: '#');

        $iconHtml = '<i class="menu-icon ' . $iconClass;
        if ($iconColorClass) $iconHtml .= ' ' . $iconColorClass;
        $iconHtml .= '"></i>';

        $linkTextSpan = '<span class="menu-text';
        if ($linkColorClass) $linkTextSpan .= ' ' . $linkColorClass;
        $linkTextSpan .= "\"> $title </span>";

        if ($hasChildren) {
            echo '<li class="dropdown">';
            echo '<a href="#" class="dropdown-toggle">';
            echo $iconHtml . $linkTextSpan;
            echo '<b class="arrow fa fa-angle-down"></b>';
            echo '</a>';
            renderMenu($item['children']);
            echo '</li>';
        } else {
            echo '<li>';
            echo "<a href=\"$url\">";
            echo $iconHtml . $linkTextSpan;
            echo '</a>';
            echo '</li>';
        }
    }
    echo '</ul>';
}
?> 

<!-- Sidebar container -->
<div id="sidebar" class="sidebar responsive ace-save-state">
    <?php
    if (!empty($menuTree)) {
        renderMenu($menuTree);
    } else {
        // fallback menu if no access
        ?>
        <ul class="nav nav-list">
            <li><a href="index.php"><i class="menu-icon fa fa-home blue"></i> Dashboard</a></li>
             <li><a href="Vision.php"><i class="menu-icon fa fa-eye blue"></i> Vision</a></li>
            <li><a href="help.php"><i class="menu-icon fa fa-history blue"></i> Help</a></li>
            <li><a href="developer_inf.php"><i class="menu-icon fa fa-users blue"></i> Developer Team</a></li>
        </ul>
        <?php
    }
    ?>
</div>