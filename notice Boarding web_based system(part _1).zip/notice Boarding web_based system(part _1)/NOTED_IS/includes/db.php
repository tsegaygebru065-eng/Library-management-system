
<?php
$host = "localhost";
$user = "root";
$password = "";
$database = "tracer_study";

$con = mysqli_connect($host, $user, $password, $database);
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}


public $full_name="";
session_start();

?>
