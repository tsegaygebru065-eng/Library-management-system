<?php include('includes/header.php');  ?>

<!-- Main Container -->
<div class="main-container ace-save-state" id="main-container">
  <?php include('includes/admin_sidemenu.php');  ?>

    <!-- Main Content -->
    <div class="main-content">
        <div class="main-content-inner">
            <div class="page-content">
                <div class="col-xs-12">

                    <!-- Instruction Card -->
                    <div class="card shadow-sm rounded-2xl p-4">
                        <div class="card-header bg-primary text-white rounded-2xl">
                            <h4><i class="fa fa-info-circle"></i> Login and Approval Guide</h4>
                        </div>
                        <div class="card-body">

                            <h5 class="text-success"><i class="fa fa-sign-in"></i> Login Steps</h5>
                            <ol class="list-group list-group-numbered mb-3">
                                <li class="list-group-item">
                                    Get your <strong>Username</strong> from the 
                                    <a href="#" target="_blank" class="btn btn-xs btn-info">
                                        <i class="fa fa-users"></i> Trainee List
                                    </a>
                                </li>
                                <li class="list-group-item">
                                    Click on the 
                                    <a href="#" target="_blank" class="btn btn-xs btn-primary">
                                        <i class="fa fa-sign-in"></i> Login
                                    </a> link.
                                </li>
                                <li class="list-group-item">
                                    Enter your <strong>Username</strong> (format: <code>AKUxxxx</code>) 
                                    and <strong>Password</strong> (default: <code>1234</code>).
                                </li>
                                <li class="list-group-item">
                                    Click the <strong>Login</strong> button to continue.
                                </li>
                            </ol>

                            <h5 class="text-success"><i class="fa fa-user-circle"></i> After Logging In</h5>
                            <ol class="list-group list-group-numbered">
                                <li class="list-group-item">Go to the <strong>My Profile</strong> page.</li>
                                <li class="list-group-item">
                                    Review your details carefully:
                                    <ul>
                                        <li>If there are <span class="text-success">no errors</span>, click the <strong>Approve</strong> button directly.</li>
                                        <li>If there are <span class="text-danger">errors</span>, click the <strong>Update</strong> button, correct your details, then click <strong>Approve</strong>.</li>
                                    </ul>
                                </li>
                                <li class="list-group-item">
                                    <strong>✅ Finally</strong>, confirm by clicking the <strong>Approve</strong> button.
                                </li>
                            </ol>

                        </div>
                    </div>
                    <!-- End Instruction Card -->

                </div>
            </div>
        </div>
    </div>
</div>

<!-- Footer -->
<?php include('includes/footer.php');  ?>
