<?php
session_start();

// Database config
$servername = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "user_profile_db";

$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

// Fetch user ID
$user_id = $_SESSION['user_id'] ?? null;
if (!$user_id) {
    $_SESSION['message'] = "User not logged in.";
    header("Location: profile.php");
    exit();
}

// Fetch POST data
$username        = $_POST['username'] ?? '';
$first_name      = $_POST['first_name'] ?? '';
$father_name     = $_POST['father_name'] ?? '';
$last_name       = $_POST['last_name'] ?? '';
$college_id      = intval($_POST['college_id'] ?? 0);
$department_id   = intval($_POST['department_id'] ?? 0);
$birth_date      = !empty($_POST['birth_date']) ? date('Y-m-d', strtotime($_POST['birth_date'])) : null;
$gender          = $_POST['gender'] ?? '';
$about           = $_POST['about'] ?? '';
$city            = $_POST['city'] ?? '';
$age             = intval($_POST['age'] ?? 0);
$email           = $_POST['email'] ?? '';
$phone           = $_POST['phone'] ?? '';
$facebook        = $_POST['facebook'] ?? '';
$twitter         = $_POST['twitter'] ?? '';
$google_plus     = $_POST['google_plus'] ?? '';
$is_public       = isset($_POST['public_profile']) ? 1 : 0;
$email_updates   = isset($_POST['email_updates']) ? 1 : 0;
$history_enabled = isset($_POST['history']) ? 1 : 0;

// Handle password
$hashed_password = null;
$new_password    = $_POST['new_password'] ?? '';
$confirm_password= $_POST['confirm_password'] ?? '';
if (!empty($new_password)) {
    if ($new_password === $confirm_password) {
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
    } else {
        $_SESSION['message'] = "Passwords do not match!";
        header("Location: profile.php");
        exit();
    }
}

// Handle photo upload (input name="Photo")
$avatar = null; // do not overwrite if no new photo
if (!empty($_FILES['Photo']['name'])) {
    $upload_dir = "uploads/avatars/";
    if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);

    $avatar_name = time() . "_" . basename($_FILES['Photo']['name']);
    $target_file = $upload_dir . $avatar_name;

    if (move_uploaded_file($_FILES['Photo']['tmp_name'], $target_file)) {
        $avatar = $target_file; // save path to database
    } else {
        $_SESSION['message'] = "Failed to upload photo.";
        header("Location: profile.php");
        exit();
    }
}

// Build SQL dynamically
$sql = "UPDATE users SET 
            username=?, first_name=?, father_name=?, last_name=?,
            college_id=?, department_id=?,
            birth_date=?, gender=?, about=?, city=?, age=?, email=?, phone=?,
            facebook=?, twitter=?, google_plus=?,
            is_public=?, email_updates=?, history_enabled=?";

$params = [
    $username, $first_name,$father_name, $last_name,
    $college_id, $department_id,
    $birth_date, $gender, $about, $city, $age, $email, $phone,
    $facebook, $twitter, $google_plus,
    $is_public, $email_updates, $history_enabled
];

$types = "ssss"   // username, first_name, last_name
       . "ii"    // college_id, department_id
       . "sss"   // birth_date, gender, about
       . "si"    // city, age
       . "ss"    // email, phone
       . "sss"   // facebook, twitter, google_plus
       . "iii";  // is_public, email_updates, history_enabled

// Add avatar if uploaded
if ($avatar) {
    $sql .= ", avatar=?";
    $types .= "s";
    $params[] = $avatar;
}

// Add password if changed
if ($hashed_password) {
    $sql .= ", new_password=?";
    $types .= "s";
    $params[] = $hashed_password;
}

// Add WHERE clause
$sql .= " WHERE id=?";
$types .= "i";
$params[] = $user_id;

// Prepare statement
$stmt = $conn->prepare($sql);
if (!$stmt) die("SQL Error: " . $conn->error);

// Bind parameters
$stmt->bind_param($types, ...$params);

// Execute
if ($stmt->execute()) {
    $_SESSION['message'] = "Profile updated successfully.";
} else {
    $_SESSION['message'] = "Error updating profile: " . $stmt->error;
}

$stmt->close();
$conn->close();

// Redirect
header("Location: profile.php");
exit();
?>