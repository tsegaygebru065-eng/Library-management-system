<?php
include('db/dbcon.php');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/* SESSION TIMEOUT */
$timeout_duration = 300;

if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY']) > $timeout_duration) {
    session_unset();
    session_destroy();
    header("Location: login.php?session=expired");
    exit();
}

$_SESSION['LAST_ACTIVITY'] = time();

/* SESSION DATA */
$isLoggedIn = $_SESSION['loggedin'] ?? false;
$role = $_SESSION['role'] ?? '';
$first_name = $_SESSION['first_name'] ?? '';
$father_name = $_SESSION['father_name'] ?? '';
$last_name = $_SESSION['last_name'] ?? '';
$full_name = trim("$first_name $father_name $last_name") ?: ($_SESSION['username'] ?? '');

$isAdmin = ($role === 'admin');
?> 
<?php include('includes/header.php'); ?>
<body class="no-skin">

<div id="main-container" class="main-container ace-save-state">

    <?php include('includes/admin_sidemenu.php'); ?>

    <!-- MAIN CONTENT -->
    <div class="main-content">
        <div class="main-content-inner">

            <div class="page-content">

<!-- SLIDER -->
<div id="mainSlider" class="carousel slide" data-ride="carousel" data-interval="4000">

<ol class="carousel-indicators">
<li data-target="#mainSlider" data-slide-to="0" class="active"></li>
<li data-target="#mainSlider" data-slide-to="1"></li>
<li data-target="#mainSlider" data-slide-to="2"></li>
</ol>

<div class="carousel-inner">

<div class="item active">
<img src="images/slide1.jpg" style="width:100%;height:420px;">
<div class="carousel-caption">
<h3>Campus Announcement</h3>
<p>Important university announcements.</p>
</div>
</div>

<div class="item">
<img src="images/slide2.jpg" style="width:100%;height:420px;">
<div class="carousel-caption">
<h3>Student Information</h3>
<p>Academic notices and schedules.</p>
</div>
</div>

<div class="item">
<img src="images/slide3.jpg" style="width:100%;height:420px;">
<div class="carousel-caption">
<h3>University Events</h3>
<p>Stay updated with campus events.</p>
</div>
</div>

</div>

<a class="left carousel-control" href="#mainSlider" data-slide="prev">
<span class="glyphicon glyphicon-chevron-left"></span>
</a>

<a class="right carousel-control" href="#mainSlider" data-slide="next">
<span class="glyphicon glyphicon-chevron-right"></span>
</a>

</div>

</div>
</div>
</div>

</div>

<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/ace-elements.min.js"></script>
<script src="assets/js/ace.min.js"></script>
<?php include('includes/footer.php'); ?>


</body>
</html>