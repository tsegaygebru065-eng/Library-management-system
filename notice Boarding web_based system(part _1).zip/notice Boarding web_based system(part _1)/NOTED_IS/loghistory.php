<?php
include('db/dbcon.php');

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if logged in
if (empty($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit;
}
include('includes/header.php'); 
?>
<div class="main-container ace-save-state" id="main-container">

    <!-- Sidebar -->
    <?php include('includes/admin_sidemenu.php'); ?>

    <!-- Main Content -->
    <div class="main-content">
        <div class="main-content-inner">
            
            <!-- Breadcrumbs -->
            <div class="breadcrumbs ace-save-state" id="breadcrumbs">
                <ul class="breadcrumb">
                    <li>
                        <i class="ace-icon fa fa-home home-icon"></i>
                        <a href="admin_dashboard.php">Home</a>
                    </li>
                    <li class="active">User Activity Log</li>
                </ul>
            </div>

            <!-- Page Content -->
            <div class="page-content">
                <div class="page-header">
                    <h1>
                        User Activity Log
                        <small><i class="ace-icon fa fa-angle-double-right"></i> View and manage user actions</small>
                    </h1>
                </div>

                <!-- Filters -->
                <div class="row mb-3">
                    <div class="col-md-4">
                        <input type="text" id="searchUser" class="form-control" placeholder="Search by User ID">
                    </div>
                    <div class="col-md-4">
                        <select id="filterAction" class="form-control">
                            <option value="">Filter by Action</option>
                            <?php
                            $actions = $conn->query("SELECT DISTINCT action_type FROM log_history ORDER BY action_type");
                            while ($act = $actions->fetch_assoc()) {
                                echo "<option value='".htmlspecialchars($act['action_type'] ?? '')."'>".htmlspecialchars($act['action_type'] ?? '')."</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <input type="date" id="filterDate" class="form-control">
                    </div>
                </div>

                <!-- Smart Table -->
                <div class="row">
                    <div class="col-xs-12">
                        <div class="table-header bg-primary text-white">
                            <i class="fa fa-history"></i> User Activity Log
                        </div>
                        <div>
                            <table id="logTable" class="table table-striped table-bordered table-hover responsive nowrap">
                                <thead class="thin-border-bottom">
                                    <tr>
                                        <th>#</th>
                                        <th>User ID</th>
                                        <th>Action</th>
                                        <th>IP Address</th>
                                        <th>Browser</th>
										
                                        <th>Description</th>
                                        <th>Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
                                $result = $conn->query("SELECT * FROM log_history ORDER BY created_at DESC ");
                                $count = 1;
                                while ($row = $result->fetch_assoc()):
                                ?>
                                    <tr>
                                        <td><?= $count ?></td>
                                        <td><?= htmlspecialchars($row['user_id'] ?? '') ?></td>
                                        <td><span class="label label-info"><?= htmlspecialchars($row['action_type'] ?? '') ?></span></td>
                                        
                                        <td><?= htmlspecialchars($row['ip_address'] ?? '') ?></td>
                                        <td><?= htmlspecialchars($row['browser_info'] ?? '') ?></td>
										<td><?= htmlspecialchars($row['action_description'] ?? '') ?></td>
                                        <td><?= htmlspecialchars($row['created_at'] ?? '') ?></td>
                                    </tr>
                                <?php $count++; endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div> <!-- /.page-content -->
        </div> <!-- /.main-content-inner -->
    </div> <!-- /.main-content -->

    <?php include('includes/footer.php'); ?>
</div> <!-- /.main-container -->

<!-- DataTables & JS -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.5.0/css/responsive.dataTables.min.css">

<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.print.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.5.0/js/dataTables.responsive.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js"></script>

<script>
$(document).ready(function(){
    var table = $('#logTable').DataTable({
        "order": [[6, "desc"]],
        "pageLength": 25,
        "lengthMenu": [[25, 50, 100, -1], [25, 50, 100, "All"]],
        responsive: true,
        buttons: [
            { extend: 'copy', className: 'btn btn-sm btn-info' },
            { extend: 'csv', className: 'btn btn-sm btn-success' },
            { extend: 'excel', className: 'btn btn-sm btn-warning' },
            { extend: 'pdf', className: 'btn btn-sm btn-primary' },
            { extend: 'print', className: 'btn btn-sm btn-default' }
        ],
        columnDefs: [
            { orderable: false, targets: [3] } // Description not sortable
        ]
    });

    // Filters
    $('#searchUser').on('keyup', function () { table.column(1).search(this.value).draw(); });
    $('#filterAction').on('change', function () { table.column(2).search(this.value).draw(); });
    $('#filterDate').on('change', function () { table.column(6).search(this.value).draw(); });
});
</script>
