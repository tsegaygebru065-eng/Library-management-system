<?php include('includes/header.php');  ?>

<!-- Main Container -->
<div class="main-container ace-save-state" id="main-container">
  
<?php include('includes/admin_sidemenu.php');  ?>
<!-- Main Content -->
<div class="main-content">
    <div class="main-content-inner">
        <div class="page-content">
            <div class="col-xs-12"> 

                <h2>Vision</h2>
                <p>
                    <strong>English:</strong><br>
                    To empower individuals with strong English communication skills, enabling them to confidently participate in global opportunities, academic pursuits, and professional growth.
                </p>
                <p>
                    <strong>አማርኛ:</strong><br>
                    ሰዎችን በጥሩ የእንግሊዝኛ ንግግር ችሎታ እንዲበረታ እና በአለም አቀፍ ዕድሎች፣ በትምህርት ሂደቶች፣ እና በሙያ እድገት እንዲተሳተፉ እንደሚያስችላቸው ማስቻል ነው።
                </p>

                <h2>Mission</h2>
                <p>
                    <strong>English:</strong><br>
                   The English Language Improvement Program (ELIP) aims to enhance the English proficiency of learners through comprehensive training in reading, writing, listening, and speaking. We are committed to creating an engaging, supportive, and practical learning environment that fosters confidence, critical thinking, and effective communication in English.
                </p>
                <p>
                    <strong>አማርኛ:</strong><br>
                    የእንግሊዝኛ ቋንቋ ማሻሻያ ፕሮግራም (ELIP) ተማሪዎችን በማንበብ፣ በመጻፍ፣ በመስማት እና በመናገር ችሎታ እንዲጠንቀቁ የሚያስችላቸውን እና የሚሰጥባቸውን አጠቃላይ ስልጠና ይሰጣል። እኛ ተማሪዎች በእንግሊዝኛ ቋንቋ እምነት፣ አስተዋይነት እና ተግባራዊ ንግግር እንዲያስገኙ የሚያስችል እና የሚያገለግል የመማር አካባቢ መፍጠር ነው።
                </p>

            </div>
        </div>
    </div>
</div>

</div>
<!-- Footer -->
<?php include('includes/footer.php');  ?>