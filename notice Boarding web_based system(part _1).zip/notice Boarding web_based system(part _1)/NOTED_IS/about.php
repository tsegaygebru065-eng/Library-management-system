<?php include('includes/header.php');  ?>
<!-- Main Container -->
<div class="main-container ace-save-state" id="main-container">
<?php include('includes/sidemenu.php');  ?>

    <!-- Main Content -->
    <div class="main-content">
        <div class="main-content-inner">
            <div class="page-content">
                <div class="col-xs-12"> 
    <h2>Vision</h2>
    <p>
        To become a leading institution in providing innovative and transformative summer training programs
        that empower educators, students, and professionals with skills aligned to national development and global trends.
    </p>

    <h2>Mission</h2>
    <p>
        Our mission is to deliver high-quality summer training programs through qualified instructors, modern pedagogy,
        and inclusive learning environments to enhance knowledge, skills, and research capacity of our participants.
    </p>
</div>
 
            </div>
        </div>
    </div>
</div>

<!-- Footer -->
<?php include('includes/footer.php');  ?>