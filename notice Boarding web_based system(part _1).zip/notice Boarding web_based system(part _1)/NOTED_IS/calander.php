<?php
include('db/dbcon.php'); // DB connection
include('includes/header.php');

?>

<!-- FullCalendar CSS -->
<link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/main.min.css" rel="stylesheet">
<!-- FullCalendar JS -->
<script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/main.min.js"></script>

<!-- Main Container -->
<div class="main-container ace-save-state" id="main-container">
<?php include('includes/admin_sidemenu.php'); ?>
    <div class="main-content">
        <div class="main-content-inner">
            <div class="page-header">
                <h1>Summer Special Training - Calendar</h1>
            </div>

            <!-- Calendar Container -->
            <div id="trainingCalendar1" style="max-width:900px; margin: 0 auto;"></div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var calendarEl = document.getElementById('trainingCalendar1');

    var calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        headerToolbar: {
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,timeGridWeek,timeGridDay'
        },
        navLinks: true,
        editable: true,
        selectable: true,
        nowIndicator: true,
        events: [
            { title: 'Orientation', start: '2025-08-20' },
            { title: 'Math Workshop', start: '2025-08-22' },
            { title: 'Science Lab', start: '2025-08-25' }
        ]
    });

    calendar.render();
});
</script>

<?php include('includes/footer.php'); ?>
