<?php
session_start(); // Ensure session is started

// Database configuration
$servername = "localhost"; // Database server
$username = "root";         // Database username
$password = "";             // Database password
$dbname = "user_profile_db"; // Database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$_SESSION['user_id']=$_SESSION['user_id'];
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ================= SESSION TIMEOUT HANDLING ==================
$timeout_duration = 300; // 5 minutes for example

if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY']) > $timeout_duration) {
    session_unset();
    session_destroy();
    header("Location: login.php?session=expired");
    exit();
}
$_SESSION['LAST_ACTIVITY'] = time();

// =============================================================

$isLoggedIn = $_SESSION['loggedin'] ?? false;
$username   = $_SESSION['username'] ?? '';
$role       = $_SESSION['role'] ?? '';
$first_name = $_SESSION['first_name'] ?? '';
$father_name= $_SESSION['father_name'] ?? '';
$last_name  = $_SESSION['last_name'] ?? '';
$full_name  = trim("$first_name $father_name $last_name") ?: $username;

//echo $_SESSION['user_id'];
// Fetch user ID from the session
$user_id = $_SESSION['user_id'] ?? null; // Ensure a valid session
if ($user_id === null) {
    die("User not logged in.");
}
// Prepare and execute the query to fetch user data
$stmt = $conn->prepare("
    SELECT 
        u.id,
        u.username,
		 u.city,
        u.first_name,
		u.father_name,
        u.last_name,
        u.email,
        u.city,
        u.age,
        u.avatar,
        u.about,
        u.created_at,
        u.birth_date,
        u.gender,
		u.age,
        u.phone,
        u.facebook,
        u.twitter,
        u.google_plus,
        u.last_online,
        u.joined,
        u.college_id,
        u.department_id,
        c.name AS college_name,
        d.name AS department_name,
        u.is_public,
        u.email_updates,
        u.history_enabled,
        u.previous_password,
        u.new_password
    FROM users u
    LEFT JOIN colleges c ON u.college_id = c.id
    LEFT JOIN departments d ON u.department_id = d.id
    WHERE u.id = ?
");
// Bind the user ID parameter as an integer
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

// Check if the user exists and fetch the data
if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
    // Format birth date for display
    $user['birth_date_formatted'] = $user['birth_date'] ? date("d-m-Y", strtotime($user['birth_date'])) : ''; // Format for dd-mm-yyyy input
} else {
    // Handle the case where the user is not found
    die("User not found.");
}

// Fetch colleges from the database
$colleges = [];
$result = $conn->query("SELECT id, name FROM colleges");
while ($row = $result->fetch_assoc()) {
    $colleges[$row['id']] = $row['name'];
}

// Fetch departments from the database
$departments = [];
$result = $conn->query("SELECT id, name FROM departments");
while ($row = $result->fetch_assoc()) {
    $departments[$row['id']] = $row['name'];
}

// Close the statement and connection
$stmt->close();
$conn->close();
?>

<?php include('includes/header.php'); ?>
<body class="no-skin">

<div id="main-container" class="main-container ace-save-state">

    <?php include('includes/admin_sidemenu.php'); ?>

    <!-- MAIN CONTENT -->
    <div class="main-content">
        <div class="main-content-inner">

                    <div class="page-header">
                        <h1>User Profile <small><i class="ace-icon fa fa-angle-double-right"></i> 2 Style User Detail & User detail editing</small></h1>
                    </div>

                    <div class="row">
                        <div class="col-xs-12">
                            <!-- Profile Style Switcher -->
                            <div class="pull-right">
                                <span class="green middle bolder">Choose profile: &nbsp;</span>
                                <div class="btn-toolbar inline middle no-margin">
                                    <div data-toggle="buttons" class="btn-group no-margin">
                                        <label class="btn btn-sm btn-yellow active">
                                            <span class="bigger-110" title="User Details">1</span>
                                            <input type="radio" value="1" checked />
                                        </label> 
                                        <label class="btn btn-sm btn-yellow">
                                            <span class="bigger-110" title="Edit User Details">2</span>
                                            <input type="radio" value="3" />
                                        </label>
                                    </div>
                                </div>
                            </div>
 

      <!-- PROFILE 1 -->
<div id="user-profile-1" class="user-profile row">
    <div class="col-xs-12 col-sm-3 center">
        <div>
            <span class="profile-picture">
                <img id="avatar" class="editable img-responsive" src="<?= htmlspecialchars($user['avatar']) ?>" alt="Avatar" />
            </span>
            <div class="space-4"></div>
            <div class="width-80 label label-info label-xlg arrowed-in arrowed-in-right">
                <div class="inline position-relative">
                    <a href="#" class="user-title-label dropdown-toggle" data-toggle="dropdown">
                        <i class="ace-icon fa fa-circle light-green"></i>
                        &nbsp;
                        <span class="white"><?= htmlspecialchars($user['first_name'] .' '. $user['father_name'].' ' . $user['last_name']) ?></span>
                    </a>
                    <ul class="align-left dropdown-menu dropdown-caret dropdown-lighter">
                        <li class="dropdown-header"> Change Status </li>
                        <li><a href="#"><i class="ace-icon fa fa-circle green"></i>&nbsp;<span class="green">Available</span></a></li>
                        <li><a href="#"><i class="ace-icon fa fa-circle red"></i>&nbsp;<span class="red">Busy</span></a></li>
                        <li><a href="#"><i class="ace-icon fa fa-circle grey"></i>&nbsp;<span class="grey">Invisible</span></a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="hr hr16 dotted"></div>
    </div>

    <div class="col-xs-12 col-sm-9">
        <div class="space-12"></div>
        <div class="profile-user-info profile-user-info-striped">
            <div class="profile-info-row">
                <div class="profile-info-name"> Username </div>
                <div class="profile-info-value"><span class="editable" id="username"><?= htmlspecialchars($user['username']) ?></span></div>
            </div>
            <div class="profile-info-row">
                <div class="profile-info-name"> College </div>
                <div class="profile-info-value"><span class="editable" id="college"><?= htmlspecialchars($user['college_name']) ?></span></div>
            </div>
            <div class="profile-info-row">
                <div class="profile-info-name"> Department </div>
                <div class="profile-info-value"><span class="editable" id="department"><?= htmlspecialchars($user['department_name']) ?></span></div>
            </div>
            <div class="profile-info-row">
                <div class="profile-info-name"> Age </div>
                <div class="profile-info-value"><span class="editable" id="age"><?= htmlspecialchars($user['age']) ?></span></div>
            </div>
            <div class="profile-info-row">
                <div class="profile-info-name"> Joined </div>
                <div class="profile-info-value"><span class="editable" id="signup"><?= htmlspecialchars($user['joined']) ?></span></div>
            </div>
            <div class="profile-info-row">
                <div class="profile-info-name"> Last Online IP</div>
                <div class="profile-info-value"><span class="editable" id="login"><?= htmlspecialchars($user['last_online']) ?></span></div>
            </div>
            <div class="profile-info-row">
                <div class="profile-info-name"> About Me </div>
                <div class="profile-info-value"><span class="editable" id="about"><?= htmlspecialchars($user['about']) ?></span></div>
            </div>
			
			<div class="profile-info-row">
                <div class="profile-info-name"> Gender </div>
                <div class="profile-info-value"><span class="editable" id="about"><?= htmlspecialchars($user['gender']) ?></span></div>
            </div>
			<div class="profile-info-row">
                <div class="profile-info-name"> Email </div>
                <div class="profile-info-value"><span class="editable" id="about"><?= htmlspecialchars($user['email']) ?></span></div>
            </div>
			<div class="profile-info-row">
                <div class="profile-info-name"> Phone </div>
                <div class="profile-info-value"><span class="editable" id="about"><?= htmlspecialchars($user['phone']) ?></span></div>
            </div>
			<div class="profile-info-row">
                <div class="profile-info-name"> Facebook </div>
                <div class="profile-info-value"><span class="editable" id="about"><?= htmlspecialchars($user['facebook']) ?></span></div>
            </div><div class="profile-info-row">
                <div class="profile-info-name"> Twitter </div>
                <div class="profile-info-value"><span class="editable" id="about"><?= htmlspecialchars($user['twitter']) ?></span></div>
            </div><div class="profile-info-row">
                <div class="profile-info-name"> Google+ </div>
                <div class="profile-info-value"><span class="editable" id="about"><?= htmlspecialchars($user['google_plus']) ?></span></div>
            </div>
			
        </div>
    </div>
</div>

 <!-- PROFILE 3 -->
                            <div id="user-profile-3" class="user-profile hide"> 
                      <div class="col-sm-offset-1 col-sm-10">
                        <form class="form-horizontal" method="POST" action="profile_update.php" enctype="multipart/form-data">
                             <input type="hidden" name="id" value="<?= htmlspecialchars($user['id']) ?>
                            
                            <div class="tabbable">
                                <ul class="nav nav-tabs padding-16">
                                    <li class="active">
                                        <a data-toggle="tab" href="#edit-basic">
                                            <i class="green ace-icon fa fa-pencil-square-o bigger-125"></i>
                                            Basic Info
                                        </a>
                                    </li>
                                 
                                    <li>
                                        <a data-toggle="tab" href="#edit-password">
                                            <i class="blue ace-icon fa fa-key bigger-125"></i>
                                            Password
                                        </a>
                                    </li>
                                </ul>

                                <div class="tab-content profile-edit-tab-content">
                                    <div id="edit-basic" class="tab-pane in active">
                                        <h4 class="header blue bolder smaller">General</h4>

                                        <div class="row">
										
                                            <div class="col-xs-12 col-sm-4">
                                          <label for="form-field-avatar">Photo:</label>
<input type="file" name="Photo" id="form-field-avatar" /><hr>
<span class="profile-user-info profile-user-info-striped">
    <?php if(!empty($user['avatar'])): ?>
        <img src="<?= htmlspecialchars($user['avatar']) ?>" alt="Avatar" style="width:120px;height:120px;"/>
    <?php else: ?>
        <img src="assets/images/avatars/profile-pic.jpg" alt="Default Avatar" style="width:120px;height:120px;"/>
    <?php endif; ?>
</span>
                                 
											<div class="form-group"><hr>
        <label>Make my profile public:</label>
        <input type="checkbox" name="public_profile" <?= ($user['is_public'] ? 'checked' : '') ?> />
    </div>

    <div class="form-group">
        <label>Email me new updates:</label>
        <input type="checkbox" name="email_updates" <?= ($user['email_updates'] ? 'checked' : '') ?> />
    </div>

    <div class="form-group">
        <label>Keep a history:</label>
        <input type="checkbox" name="history" <?= ($user['history_enabled'] ? 'checked' : '') ?> />
    </div>
	<div class="form-group">
                                            <label class="col-sm-3 control-label no-padding-right" for="form-field-comment">About:</label>
                                            <div class="col-sm-9">
                                                <textarea id="form-field" name="about"  id="about"><?= htmlspecialchars($user['about']) ?></textarea>
                                            </div>
                                        </div>
										
	</div>
											

                                            <div class="vspace-12-sm"></div>

                                            <div class="col-xs-12 col-sm-8">
                                                <div class="form-group">
                                                    <label class="col-sm-4 control-label no-padding-right" for="form-field-username">Username</label>
                                                    <div class="col-sm-8">
                                                        <input class="col-xs-12 col-sm-10" type="text" id="form-field-username" readonly name="username" value="<?= htmlspecialchars($user['username']) ?>" />
                                                    </div>
                                                </div>

                                                <div class="space-4"></div>

                                                <div class="form-group">
                                                    <label class="col-sm-4 control-label no-padding-right" for="form-field-first">First Name</label>
                                                    <div class="col-sm-8">
                                                        <input class="input-small" type="text" id="form-field-first" name="first_name" value="<?= htmlspecialchars($user['first_name']) ?>" />
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <label class="col-sm-4 control-label no-padding-right" for="form-field-last">Father Name</label>
                                                    <div class="col-sm-8">
                                                        <input class="input-small" type="text" id="form-field-last" name="father_name" value="<?= htmlspecialchars($user['father_name']) ?>" />
                                                    </div>
                                                </div>
												<div class="form-group">
                                                    <label class="col-sm-4 control-label no-padding-right" for="form-field-last">Last Name</label>
                                                    <div class="col-sm-8">
                                                        <input class="input-small" type="text" id="form-field-last" name="last_name" value="<?= htmlspecialchars($user['last_name']) ?>" />
                                                    </div>
                                                </div>
<div class="form-group">
    <label class="col-sm-4 control-label no-padding-right" for="form-field-college">College</label>
    <div class="col-sm-8">
        <select class="col-xs-12" id="form-field-college" name="college_id">
            <option value="">Select College</option>

            <?php foreach ($colleges as $id => $name): ?>
                <option value="<?= $id ?>" <?= ($id == $user['college_id']) ? 'selected' : ''; ?>>
                    <?= htmlspecialchars($name) ?>
                </option>
            <?php endforeach; ?>

        </select>
    </div>
</div>


<div class="form-group">
    <label class="col-sm-4 control-label no-padding-right" for="form-field-department">Department</label>
    <div class="col-sm-8">
        <select class="col-xs-12" id="form-field-department" name="department_id">
            <option value="">Select Department</option>

            <?php foreach ($departments as $id => $name): ?>
                <option value="<?= $id ?>" <?= ($id == $user['department_id']) ? 'selected' : ''; ?>>
                    <?= htmlspecialchars($name) ?>
                </option>
            <?php endforeach; ?>

        </select>
    </div>
</div>
                                   <div class="form-group">
                                            <label class="col-sm-3 control-label no-padding-right" for="form-field-date">Birth Date</label>
                                            <div class="col-sm-9">
                                                <div class="input-medium">
                                                    <div class="input-group">
                                                        <input class="input-medium date-picker" id="form-field-date" type="text" data-date-format="dd-mm-yyyy" placeholder="dd-mm-yyyy" name="birth_date" value="<?= htmlspecialchars($user['birth_date_formatted']) ?>" />
                                                        <span class="input-group-addon">
                                                            <i class="ace-icon fa fa-calendar"></i>
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
										<div class="form-group">
                                            <label class="col-sm-3 control-label no-padding-right" for="form-field-date">Age</label>
                                            <div class="col-sm-9">
                                                <div class="input-medium">
                                                    <div class="input-group">
                                                        <input class="input-medium" id="form-field" type="number"  placeholder="dd-mm-yyyy" name="age" value="<?= htmlspecialchars($user['age']) ?>" />
                                                         
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label class="col-sm-3 control-label no-padding-right">Gender</label>
                                            <div class="col-sm-9">
                                                <label class="inline">
                                                    <input name="gender" type="radio" class="ace" value="Male" <?= ($user['gender'] === 'Male') ? 'checked' : ''; ?> />
                                                    <span class="lbl middle"> Male</span>
                                                </label>
                                                &nbsp; &nbsp; &nbsp;
                                                <label class="inline">
                                                    <input name="gender" type="radio" class="ace" value="Female" <?= ($user['gender'] === 'Female') ? 'checked' : ''; ?> />
                                                    <span class="lbl middle"> Female</span>
                                                </label>
                                            </div>
                                        </div>

                                            </div>
                                        </div>

                                        <hr /> 
                                        <h4 class="header blue bolder smaller">Contact</h4>
<div class="form-group">
                                            <label class="col-sm-3 control-label no-padding-right" for="form-field-comment">City</label>
                                            <div class="col-sm-9"> 
        <span class="input-icon input-icon-right">
                                            <input class="input-medium input" type="text" id="city" name="city" value="<?= htmlspecialchars($user['city']) ?>" />
											<i class="ace-icon fa fa-pencil-square-o"></i>
                    </span>
			</div>
                                        </div>
<div class="form-group">
    <label class="col-sm-3 control-label no-padding-right" for="form-field-email">Email</label>
    <div class="col-sm-9">
        <span class="input-icon input-icon-right">
            <input type="email" id="form-field-email" name="email" value="<?= htmlspecialchars($user['email']) ?>" />
            <i class="ace-icon fa fa-envelope"></i>
        </span>
    </div>
</div>

<div class="space-4"></div>

<div class="form-group">
    <label class="col-sm-3 control-label no-padding-right" for="form-field-phone">Phone</label>
    <div class="col-sm-9">
        <span class="input-icon input-icon-right">
            <input class="input-medium input-mask-phone" type="text" id="form-field-phone" name="phone" value="<?= htmlspecialchars($user['phone']) ?>" />
            <i class="ace-icon fa fa-phone fa-flip-horizontal"></i>
        </span>
    </div>
</div>

<div class="space"></div>
<h4 class="header blue bolder smaller">Social</h4>

<div class="form-group">
    <label class="col-sm-3 control-label no-padding-right" for="form-field-facebook">Facebook</label>
    <div class="col-sm-9">
        <span class="input-icon">
            <input type="text" id="form-field-facebook" name="facebook" value="<?= htmlspecialchars($user['facebook']) ?>" />
            <i class="ace-icon fa fa-facebook blue"></i>
        </span>
    </div>
</div>

<div class="space-4"></div>

<div class="form-group">
    <label class="col-sm-3 control-label no-padding-right" for="form-field-twitter">Twitter</label>
    <div class="col-sm-9">
        <span class="input-icon">
            <input type="text" id="form-field-twitter" name="twitter" value="<?= htmlspecialchars($user['twitter']) ?>" />
            <i class="ace-icon fa fa-twitter light-blue"></i>
        </span>
    </div>
</div>

<div class="space-4"></div>

<div class="form-group">
    <label class="col-sm-3 control-label no-padding-right" for="form-field-gplus">Google+</label>
    <div class="col-sm-9">
        <span class="input-icon">
            <input type="text" id="form-field-gplus" name="google_plus" value="<?= htmlspecialchars($user['google_plus']) ?>" />
            <i class="ace-icon fa fa-google-plus red"></i>
        </span>
    </div>
</div>
                               
                                    </div>

                                    <div id="edit-password" class="tab-pane">
                                        <h4 class="header blue bolder smaller">Change Password</h4>
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label no-padding-right" for="form-field-pass1">New Password</label>
                                            <div class="col-sm-9">
                                                <input type="password" id="form-field-pass1" name="new_password" />
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label class="col-sm-3 control-label no-padding-right" for="form-field-pass2">Confirm Password</label>
                                            <div class="col-sm-9">
                                                <input type="password" id="form-field-pass2" name="confirm_password" />
                                            </div>
                                        </div>
                                    </div>
	<div class="space"></div>
 </div>
								
                            </div>

                            <div class="clearfix form-actions">
                                <div class="col-md-offset-3 col-md-9">
                                    <button class="btn btn-info" type="submit">
                                        <i class="ace-icon fa fa-check bigger-110"></i>
                                        Save
                                    </button>
                                    &nbsp; &nbsp;
                                    <button class="btn" type="reset">
                                        <i class="ace-icon fa fa-undo bigger-110"></i>
                                        Reset
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
               </div> <!-- /user-profile -->
                       	 

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="assets/js/jquery-2.1.4.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/jquery-ui.custom.min.js"></script>
    <script src="assets/js/select2.min.js"></script>
    <script src="assets/js/bootstrap-editable.min.js"></script>
    <script src="assets/js/ace-elements.min.js"></script>
    <script src="assets/js/ace.min.js"></script>
<script>
$(document).ready(function(){

    var college_id = $('#form-field-college').val();
    var selected_department = "<?= $user['department_id'] ?>";

    if(college_id != '')
    {
        loadDepartments(college_id, selected_department);
    }

    $('#form-field-college').change(function(){

        var college_id = $(this).val();

        if(college_id != '')
        {
            loadDepartments(college_id, '');
        }
        else
        {
            $('#form-field-department').html('<option value="">Select Department</option>');
        }

    });

    function loadDepartments(college_id, selected_department)
    {
        $.ajax({
            url: "get_departments.php",
            type: "POST",
            data: {
                college_id: college_id,
                selected_department: selected_department
            },
            success:function(data){
                $('#form-field-department').html(data);
            }
        });
    }

});
</script>
    <script>
    $(function(){
        // Switch profiles
        $('[data-toggle="buttons"] .btn').on('click', function(){
            var target = $(this).find('input[type=radio]').val();
            $('.user-profile').addClass('hide');
            $('#user-profile-'+target).removeClass('hide');
        });

        // Inline editable example
        $.fn.editable.defaults.mode = 'inline'; 
        $('#about').editable({type: 'wysiwyg'});
    });
    </script>

	
</body>
</html>