<?php include('includes/header.php'); ?>

<!-- Main Container -->
<div class="main-container ace-save-state" id="main-container">
  <?php include('includes/admin_sidemenu.php'); ?>

  <!-- Main Content -->
  <div class="main-content">
    <div class="main-content-inner">
      <div class="page-content">
        <div class="col-xs-12">
          <div class="row">
            <div class="col-xs-12">
              <!-- PAGE CONTENT BEGINS -->
              <h3>
                <i class="icon-group"></i>&nbsp;
                <span class="inverse"><b><u>Developer's Information</u></b></span>
              </h3>

              <div class="profile-container">
                <ul class="profile-list">
                  <?php
                  // Smart developer array
                  $developers = [
                      [
                          'name' => 'Abadi Desta Tesfay',
                          'image' => 'images/abadi.jpg',
                          'address' => 'Aksum-Tigray-Ethiopia',
                          'email' => 'abadidesta19@gmail.com',
                          'phone' => '+251914803378',
                          'role' => 'developer'
                      ],
                      // Add more developers here
                  ];

                  foreach ($developers as $dev): ?>
                    <li class="profile-card <?= $dev['role'] ?>-card">
                      <img src="<?= $dev['image'] ?>" alt="<?= htmlspecialchars($dev['name']) ?>" />
                      <hr>
                      <p class="info"><strong>Name:</strong> <?= htmlspecialchars($dev['name']) ?></p>
                      <p class="info"><strong>Address:</strong> <?= htmlspecialchars($dev['address']) ?></p>
                      <p class="info"><strong>Email:</strong> <a href="mailto:<?= $dev['email'] ?>"><?= $dev['email'] ?></a></p>
                      <p class="info"><strong>Phone:</strong> <a href="tel:<?= $dev['phone'] ?>"><?= $dev['phone'] ?></a></p>
                    </li>
                  <?php endforeach; ?>
                </ul>
              </div>

              <style>
                /* Container & list styling */
                .profile-container {
                    padding: 20px;
                    background: #f9f9f9;
                }

                .profile-list {
                    display: flex;
                    flex-wrap: wrap;
                    gap: 20px;
                    list-style: none;
                    padding: 0;
                    margin: 0;
                    justify-content: center;
                }

                /* Card styling */
                .profile-card {
                    background: #fff;
                    border-radius: 15px;
                    box-shadow: 0 4px 10px rgba(0,0,0,0.1);
                    padding: 20px;
                    text-align: center;
                    width: 250px;
                    transition: transform 0.3s, box-shadow 0.3s;
                }

                .profile-card img {
                    border-radius: 50%;
                    width: 100px;
                    height: 100px;
                    object-fit: cover;
                }

                .profile-card hr {
                    margin: 10px 0;
                    border: 0;
                    border-top: 1px solid #ddd;
                }

                /* Text info */
                .info {
                    margin: 5px 0;
                    color: #333;
                    font-size: 14px;
                }

                .profile-card a {
                    color: #1e90ff;
                    text-decoration: none;
                }

                .profile-card a:hover {
                    text-decoration: underline;
                }

                /* Developer vs University colors */
                .developer-card {
                    border: 3px solid #28a745; /* green */
                }

                .university-card {
                    border: 3px solid #dc3545; /* red */
                }

                /* Hover effect */
                .profile-card:hover {
                    transform: translateY(-5px);
                    box-shadow: 0 8px 20px rgba(0,0,0,0.2);
                }

                /* Responsive */
                @media (max-width: 600px) {
                    .profile-list {
                        flex-direction: column;
                        align-items: center;
                    }
                }
              </style>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Footer -->
<?php include('includes/footer.php'); ?>