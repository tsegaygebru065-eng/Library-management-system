<?php
include('db/dbcon.php');

if (session_status() === PHP_SESSION_NONE) { 
    session_start(); 
}

$username = $_SESSION['username'] ?? '';

/* ---------- POST HANDLER ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Save role
    if (isset($_POST['save_role'])) {
        $rid = $_POST['rid'] ?? '';
        $role_name = trim($_POST['role_name']);
        $description = trim($_POST['desc_role']);
        $status = isset($_POST['status']) ? 1 : 0;

        if ($rid) {
            // Update existing role
            $stmt = $conn->prepare("UPDATE role_data SET role_name=?, description=?, status=?, record_updated_by=?, record_updated_date=NOW() WHERE rid=?");
            $stmt->bind_param("ssisi", $role_name, $description, $status, $username, $rid);
            $stmt->execute();
            $stmt->close();
        } else {
            // Insert new role
            $stmt = $conn->prepare("INSERT INTO role_data (role_name, description, status, record_by, record_date, record_updated_by, record_updated_date) VALUES (?, ?, ?, ?, NOW(), ?, NOW())");
            $stmt->bind_param("sisss", $role_name, $description, $status, $username, $username);
            $stmt->execute();
            $rid = $conn->insert_id;
            $stmt->close();
        }

        // Update menu access
        $conn->query("DELETE FROM role_menu_access WHERE role_id=".(int)$rid);
        if (!empty($_POST['menu_ids']) && is_array($_POST['menu_ids'])) {
            $stmtMenu = $conn->prepare("INSERT INTO role_menu_access (role_id, menu_id) VALUES (?, ?)");
            foreach ($_POST['menu_ids'] as $menu_id) {
                $menu_id = (int)$menu_id;
                $stmtMenu->bind_param("ii", $rid, $menu_id);
                $stmtMenu->execute();
            }
            $stmtMenu->close();
        }

        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    }

    // Delete role
    if (isset($_POST['delete_role'])) {
        $rid = (int)$_POST['rid'];

        // Check role in use
        $stmtCheck = $conn->prepare("SELECT COUNT(*) FROM user_roles WHERE role_id=?");
        $stmtCheck->bind_param("i", $rid);
        $stmtCheck->execute();
        $stmtCheck->bind_result($count);
        $stmtCheck->fetch();
        $stmtCheck->close();

        if ($count == 0) {
            $stmt1 = $conn->prepare("DELETE FROM role_menu_access WHERE role_id=?");
            $stmt1->bind_param("i", $rid);
            $stmt1->execute();
            $stmt1->close();

            $stmt2 = $conn->prepare("DELETE FROM role_data WHERE rid=?");
            $stmt2->bind_param("i", $rid);
            $stmt2->execute();
            $stmt2->close();
        }

        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    }
}

/* ---------- FETCH MENUS ---------- */
$menuList = [];
$menusRes = $conn->query("SELECT * FROM menu_items ORDER BY sort_order, title");
while ($menu = $menusRes->fetch_assoc()) {
    $menuList[] = $menu;
}

/* ---------- FETCH ROLE-MENU ASSIGNMENTS ---------- */
$roleMenusAll = [];
$res = $conn->query("SELECT role_id, menu_id FROM role_menu_access");
while ($row = $res->fetch_assoc()) {
    $roleMenusAll[$row['role_id']][] = (int)$row['menu_id'];
}
?>

<?php include('includes/header.php'); ?>
<body class="no-skin">
<div id="main-container" class="main-container ace-save-state">
<?php include('includes/admin_sidemenu.php'); ?>

<div class="main-content">
    <div class="main-content-inner">
        <div class="page-content">
            <div class="page-header clearfix">
                <h1 class="pull-left">Role Management</h1>
                <button class="btn btn-success pull-right" onclick="openAddModal()">
                    <i class="fa fa-plus"></i> Add Role
                </button>
            </div>

            <table id="roles-table" class="table table-bordered table-striped table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Role</th>
                        <th>User Full Name</th>
                        <th>Phone</th>
                        <th>Email</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                $counter = 1;
                $sql = "SELECT r.rid, r.role_name, r.description, r.status, u.first_name, u.father_name, u.last_name, u.phone_number, u.email
                        FROM role_data r
                        LEFT JOIN user_roles ur ON r.rid = ur.role_id
                        LEFT JOIN users u ON ur.user_id = u.user_id
                        ORDER BY r.role_name ASC";
                $result = $conn->query($sql);
                if ($result && $result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $fullName = trim($row['first_name'] . ' ' . $row['father_name']);
                        echo '<tr>';
                        echo '<td>'.$counter++.'</td>';
                        echo '<td>'.htmlspecialchars($row['role_name']).'</td>';
                        echo '<td>'.htmlspecialchars($fullName ?: 'N/A').'</td>';
                        echo '<td>'.htmlspecialchars($row['phone_number'] ?: 'N/A').'</td>';
                        echo '<td>'.htmlspecialchars($row['email'] ?: 'N/A').'</td>';
                        echo '<td>'.($row['status']==1 ? '<span class="badge badge-success">Active</span>' : '<span class="badge badge-danger">Inactive</span>').'</td>';
                        $roleJS = json_encode(['rid'=>$row['rid'],'role_name'=>$row['role_name'],'description'=>$row['description'],'status'=>$row['status']]);
                        echo '<td>
                                <button class="btn btn-xs btn-info" onclick=\'openEditModal('.$roleJS.')\'><i class="fa fa-edit"></i></button>
                                <button class="btn btn-xs btn-danger" onclick="openDeleteModal('.(int)$row['rid'].')"><i class="fa fa-trash"></i></button>
                              </td>';
                        echo '</tr>';
                    }
                } else {
                    echo '<tr><td colspan="7" class="text-center">No roles found.</td></tr>';
                }
                ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- MODALS: Add/Edit -->
<div class="modal fade" id="roleModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form method="POST" id="roleForm">
                <input type="hidden" name="rid" id="rid" value="">
                <input type="hidden" name="save_role" value="1">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title" id="modalTitle">Add Role</h4>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="role_name">Role Name</label>
                        <input type="text" name="role_name" id="role_name" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Status</label><br>
                        <label class="checkbox-inline">
                            <input type="checkbox" name="status" id="status_toggle" value="1"> Active
                        </label>
                    </div>
                    <div class="form-group">
                        <label for="desc_role">Description</label>
                        <textarea name="desc_role" id="desc_role" class="form-control"></textarea>
                    </div>
                    <div class="form-group">
                        <label>Assign Menus</label>
                        <div style="max-height:300px; overflow-y:auto; border:1px solid #ccc; padding:10px;">
                            <?php foreach ($menuList as $menu): ?>
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" name="menu_ids[]" value="<?= (int)$menu['menu_id'] ?>">
                                        <?= htmlspecialchars($menu['title']) ?>
                                    </label>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Save</button>
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- DELETE MODAL -->
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-sm" role="document">
        <div class="modal-content">
            <form method="POST">
                <input type="hidden" name="rid" id="delete_rid">
                <input type="hidden" name="delete_role" value="1">
                <div class="modal-header">
                    <h4 class="modal-title text-danger">Confirm Delete</h4>
                </div>
                <div class="modal-body">Are you sure you want to delete this role?</div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-danger">Delete</button>
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include('includes/footer.php'); ?>

<script>
var roleMenusAll = <?= json_encode($roleMenusAll) ?>;

function openAddModal() {
    $('#modalTitle').text('Add Role');
    $('#rid').val('');
    $('#role_name').val('');
    $('#desc_role').val('');
    $('#status_toggle').prop('checked', false);
    $('input[name="menu_ids[]"]').prop('checked', false);
    $('#roleModal').modal('show');
}

function openEditModal(role) {
    $('#modalTitle').text('Edit Role');
    $('#rid').val(role.rid);
    $('#role_name').val(role.role_name);
    $('#desc_role').val(role.description);
    $('#status_toggle').prop('checked', role.status == 1);

    // update menu checkboxes
    $('input[name="menu_ids[]"]').prop('checked', false);
    if (roleMenusAll[role.rid]) {
        roleMenusAll[role.rid].forEach(id => {
            $('input[name="menu_ids[]"][value="' + id + '"]').prop('checked', true);
        });
    }

    $('#roleModal').modal('show');
}

function openDeleteModal(rid) {
    $('#delete_rid').val(rid);
    $('#deleteModal').modal('show');
}

jQuery(function($) {
    $('#roles-table').DataTable({
        pageLength: 10,
        ordering: true,
        searching: true,
        info: true,
        autoWidth: false,
        columnDefs: [
            { orderable: false, targets: [5,6] }
        ]
    });
});
</script>
</body>
</html>