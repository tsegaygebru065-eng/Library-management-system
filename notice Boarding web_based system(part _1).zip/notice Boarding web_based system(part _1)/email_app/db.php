<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "email_app";

$conn = new mysqli($servername, $username, $password, $dbname);
$conn->set_charset("utf8");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Example query for inbox messages
$inbox_result = $conn->query("
    SELECT m.id, u.name AS sender, m.subject, m.body, ms.is_read, ms.is_starred, ms.folder
    FROM messages m
    JOIN message_status ms ON m.id = ms.message_id
    JOIN users u ON m.sender_id = u.id
    WHERE ms.user_id = 1 AND ms.folder = 'inbox'
    ORDER BY m.created_at DESC
");
?>