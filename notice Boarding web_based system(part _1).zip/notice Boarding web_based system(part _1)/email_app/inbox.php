<?php
 
// db.php - Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "email_app";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
$conn->set_charset("utf8");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <meta charset="utf-8" />
    <title>Inbox - Ace Admin</title>

    <meta name="description" content="Mailbox with some customizations as described in docs" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />

    <!-- bootstrap & fontawesome -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
    <link rel="stylesheet" href="assets/font-awesome/4.5.0/css/font-awesome.min.css" />

    <!-- page specific plugin styles -->
    
    <!-- text fonts -->
    <link rel="stylesheet" href="assets/css/fonts.googleapis.com.css" />

    <!-- ace styles -->
    <link rel="stylesheet" href="assets/css/ace.min.css" class="ace-main-stylesheet" id="main-ace-style" />

    <!--[if lte IE 9]>
        <link rel="stylesheet" href="assets/css/ace-part2.min.css" />
    <![endif]-->
    <link rel="stylesheet" href="assets/css/ace-skins.min.css" /> 
    <link rel="stylesheet" href="assets/css/ace-rtl.min.css" />

    <!--[if lte IE 9]>
        <link rel="stylesheet" href="assets/css/ace-ie.min.css" />
    <![endif]-->

    <!-- inline styles related to this page -->

    <!-- ace settings handler -->
    <script src="assets/js/ace-extra.min.js"></script>

    <!-- HTML5shiv and Respond.js for IE8 to support HTML5 elements and media queries -->
    <!--[if lte IE 8]>
    <script src="assets/js/html5shiv.min.js"></script>
    <script src="assets/js/respond.min.js"></script>
    <![endif]-->
</head>
<body class="no-skin">
    <div id="navbar" class="navbar navbar-default ace-save-state">
        <div class="navbar-container ace-save-state" id="navbar-container">
            <button type="button" class="navbar-toggle menu-toggler pull-left" id="menu-toggler" data-target="#sidebar">
                <span class="sr-only">Toggle sidebar</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>

            <div class="navbar-header pull-left">
                <a href="index.html" class="navbar-brand">
                    <small>
                        <i class="fa fa-leaf"></i>
                        Ace Admin
                    </small>
                </a>
            </div>

            <div class="navbar-buttons navbar-header pull-right" role="navigation">
                <ul class="nav ace-nav">
                    <li class="light-blue dropdown-modal">
                        <a data-toggle="dropdown" href="#" class="dropdown-toggle">
                            <img class="nav-user-photo" src="assets/images/avatars/user.jpg" alt="User's Photo" />
                            <span class="user-info">
                                <small>Welcome,</small>
                                Jason
                            </span>
                            <i class="ace-icon fa fa-caret-down"></i>
                        </a>

                        <ul class="user-menu dropdown-menu-right dropdown-menu dropdown-yellow dropdown-caret dropdown-close">
                            <li>
                                <a href="#">
                                    <i class="ace-icon fa fa-cog"></i>
                                    Settings
                                </a>
                            </li>
                            <li>
                                <a href="profile.html">
                                    <i class="ace-icon fa fa-user"></i>
                                    Profile
                                </a>
                            </li>
                            <li class="divider"></li>
                            <li>
                                <a href="#">
                                    <i class="ace-icon fa fa-power-off"></i>
                                    Logout
                                </a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div><!-- /.navbar-container -->
    </div>

    <div class="main-container ace-save-state" id="main-container">
        <script type="text/javascript">
            try{ace.settings.loadState('main-container')}catch(e){}
        </script>

        <div id="sidebar" class="sidebar responsive ace-save-state">
            <script type="text/javascript">
                try{ace.settings.loadState('sidebar')}catch(e){}
            </script>
            <ul class="nav nav-list">                    
                <li class="active open">
                    <a href="#" class="dropdown-toggle">
                        <i class="menu-icon fa fa-tag"></i>
                        <span class="menu-text"> More Pages </span>
                        <b class="arrow fa fa-angle-down"></b>
                    </a>
                    <ul class="submenu">
                        <li class="">
                            <a href="profile.html">
                                <i class="menu-icon fa fa-caret-right"></i>
                                User Profile
                            </a>
                            <b class="arrow"></b>
                        </li>
                        <li class="active">
                            <a href="inbox.php">
                                <i class="menu-icon fa fa-caret-right"></i>
                                Inbox
                            </a>
                            <b class="arrow"></b>
                        </li>
                    </ul>
                </li>
            </ul><!-- /.nav-list -->

            <div class="sidebar-toggle sidebar-collapse" id="sidebar-collapse">
                <i id="sidebar-toggle-icon" class="ace-icon fa fa-angle-double-left ace-save-state" data-icon1="ace-icon fa fa-angle-double-left" data-icon2="ace-icon fa fa-angle-double-right"></i>
            </div>
        </div>

        <div class="main-content">
            <div class="main-content-inner">
                <div class="breadcrumbs ace-save-state" id="breadcrumbs">
                    <ul class="breadcrumb">
                        <li>
                            <i class="ace-icon fa fa-home home-icon"></i>
                            <a href="#">Home</a>
                        </li>
                        <li>
                            <a href="#">More Pages</a>
                        </li>
                        <li class="active">Inbox</li>
                    </ul><!-- /.breadcrumb -->

                    <div class="nav-search" id="nav-search">
                        <form class="form-search">
                            <span class="input-icon">
                                <input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
                                <i class="ace-icon fa fa-search nav-search-icon"></i>
                            </span>
                        </form>
                    </div><!-- /.nav-search -->
                </div>

                <div class="page-content">
                    <div class="page-header">
                        <h1>
                            Inbox
                            <small>
                                <i class="ace-icon fa fa-angle-double-right"></i>
                                Mailbox with some customizations as described in docs
                            </small>
                        </h1>
                    </div><!-- /.page-header -->

                    <div class="row">
                        <div class="col-xs-12">
                            <!-- PAGE CONTENT BEGINS -->
                            <div class="row">
                                <div class="col-xs-12">
                                    <div class="tabbable">
                                        <ul id="inbox-tabs" class="inbox-tabs nav nav-tabs padding-16 tab-size-bigger tab-space-1">
                                            <li class="li-new-mail pull-right">
                                                <a data-toggle="tab" href="#write" data-target="write" class="btn-new-mail">
                                                    <span class="btn btn-purple no-border">
                                                        <i class="ace-icon fa fa-envelope bigger-130"></i>
                                                        <span class="bigger-110">Write Mail</span>
                                                    </span>
                                                </a>
                                            </li><!-- /.li-new-mail -->

                                            <li class="active">
                                                <a data-toggle="tab" href="#inbox" data-target="inbox">
                                                    <i class="blue ace-icon fa fa-inbox bigger-130"></i>
                                                    <span class="bigger-110">Inbox</span>
                                                </a>
                                            </li>

                                            <li>
                                                <a data-toggle="tab" href="#sent" data-target="sent">
                                                    <i class="orange ace-icon fa fa-location-arrow bigger-130"></i>
                                                    <span class="bigger-110">Sent</span>
                                                </a>
                                            </li>

                                            <li>
                                                <a data-toggle="tab" href="#draft" data-target="draft">
                                                    <i class="green ace-icon fa fa-pencil bigger-130"></i>
                                                    <span class="bigger-110">Draft</span>
                                                </a>
                                            </li>

                                            <li class="dropdown">
                                                <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                                                    <i class="pink ace-icon fa fa-tags bigger-130"></i>
                                                    <span class="bigger-110">
                                                        Tags
                                                        <i class="ace-icon fa fa-caret-down"></i>
                                                    </span>
                                                </a>
                                                <ul class="dropdown-menu dropdown-light-blue dropdown-125">
                                                    <li>
                                                        <a data-toggle="tab" href="#tag-1">
                                                            <span class="mail-tag badge badge-pink"></span>
                                                            <span class="pink">Tag#1</span>
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a data-toggle="tab" href="#tag-family">
                                                            <span class="mail-tag badge badge-success"></span>
                                                            <span class="green">Family</span>
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a data-toggle="tab" href="#tag-friends">
                                                            <span class="mail-tag badge badge-info"></span>
                                                            <span class="blue">Friends</span>
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a data-toggle="tab" href="#tag-work">
                                                            <span class="mail-tag badge badge-grey"></span>
                                                            <span class="grey">Work</span>
                                                        </a>
                                                    </li>
                                                </ul>
                                            </li><!-- /.dropdown -->
                                        </ul>

                                        <div class="tab-content no-border no-padding">
                                            <div id="inbox" class="tab-pane in active">
                                                <div class="message-container">
                                                    <div id="id-message-list-navbar" class="message-navbar clearfix">
                                                        <div class="message-bar">
                                                            <div class="message-infobar" id="id-message-infobar">
                                                                <span class="blue bigger-150">Inbox</span>
                                                                <span class="grey bigger-110">(2 unread messages)</span>
                                                            </div>
                                                            <div class="message-toolbar hide">
                                                                <div class="inline position-relative align-left">
                                                                    <button type="button" class="btn-white btn-primary btn btn-xs dropdown-toggle" data-toggle="dropdown">
                                                                        <span class="bigger-110">Action</span>
                                                                        <i class="ace-icon fa fa-caret-down icon-on-right"></i>
                                                                    </button>
                                                                    <ul class="dropdown-menu dropdown-lighter dropdown-caret dropdown-125">
                                                                        <li><a href="#"><i class="ace-icon fa fa-mail-reply blue"></i>&nbsp; Reply</a></li>
                                                                        <li><a href="#"><i class="ace-icon fa fa-mail-forward green"></i>&nbsp; Forward</a></li>
                                                                        <li><a href="#"><i class="ace-icon fa fa-folder-open orange"></i>&nbsp; Archive</a></li>
                                                                        <li class="divider"></li>
                                                                        <li><a href="#"><i class="ace-icon fa fa-eye blue"></i>&nbsp; Mark as read</a></li>
                                                                        <li><a href="#"><i class="ace-icon fa fa-eye-slash green"></i>&nbsp; Mark unread</a></li>
                                                                        <li><a href="#"><i class="ace-icon fa fa-flag-o red"></i>&nbsp; Flag</a></li>
                                                                        <li class="divider"></li>
                                                                        <li><a href="#"><i class="ace-icon fa fa-trash-o red bigger-110"></i>&nbsp; Delete</a></li>
                                                                    </ul>
                                                                </div>
                                                                <div class="inline position-relative align-left">
                                                                    <button type="button" class="btn-white btn-primary btn btn-xs dropdown-toggle" data-toggle="dropdown">
                                                                        <i class="ace-icon fa fa-folder-o bigger-110 blue"></i>
                                                                        <span class="bigger-110">Move to</span>
                                                                        <i class="ace-icon fa fa-caret-down icon-on-right"></i>
                                                                    </button>
                                                                    <ul class="dropdown-menu dropdown-lighter dropdown-caret dropdown-125">
                                                                        <li><a href="#"><i class="ace-icon fa fa-stop pink2"></i>&nbsp; Tag#1</a></li>
                                                                        <li><a href="#"><i class="ace-icon fa fa-stop blue"></i>&nbsp; Family</a></li>
                                                                        <li><a href="#"><i class="ace-icon fa fa-stop green"></i>&nbsp; Friends</a></li>
                                                                        <li><a href="#"><i class="ace-icon fa fa-stop grey"></i>&nbsp; Work</a></li>
                                                                    </ul>
                                                                </div>
                                                                <button type="button" class="btn btn-xs btn-white btn-primary">
                                                                    <i class="ace-icon fa fa-trash-o bigger-125 orange"></i>
                                                                    <span class="bigger-110">Delete</span>
                                                                </button>
                                                            </div>
                                                        </div>
                                                        <div>
                                                            <div class="messagebar-item-left">
                                                                <label class="inline middle">
                                                                    <input type="checkbox" id="id-toggle-all" class="ace" />
                                                                    <span class="lbl"></span>
                                                                </label>
                                                                &nbsp;
                                                                <div class="inline position-relative">
                                                                    <a href="#" data-toggle="dropdown" class="dropdown-toggle">
                                                                        <i class="ace-icon fa fa-caret-down bigger-125 middle"></i>
                                                                    </a>
                                                                    <ul class="dropdown-menu dropdown-lighter dropdown-100">
                                                                        <li><a id="id-select-message-all" href="#">All</a></li>
                                                                        <li><a id="id-select-message-none" href="#">None</a></li>
                                                                        <li class="divider"></li>
                                                                        <li><a id="id-select-message-unread" href="#">Unread</a></li>
                                                                        <li><a id="id-select-message-read" href="#">Read</a></li>
                                                                    </ul>
                                                                </div>
                                                            </div>

                                                            <div class="messagebar-item-right">
                                                                <div class="inline position-relative">
                                                                    <a href="#" data-toggle="dropdown" class="dropdown-toggle">
                                                                        Sort &nbsp;
                                                                        <i class="ace-icon fa fa-caret-down bigger-125"></i>
                                                                    </a>
                                                                    <ul class="dropdown-menu dropdown-lighter dropdown-menu-right dropdown-100">
                                                                        <li><a href="#"><i class="ace-icon fa fa-check green"></i> Date</a></li>
                                                                        <li><a href="#"><i class="ace-icon fa fa-check invisible"></i> From</a></li>
                                                                        <li><a href="#"><i class="ace-icon fa fa-check invisible"></i> Subject</a></li>
                                                                    </ul>
                                                                </div>
                                                            </div>

                                                            <div class="nav-search minimized">
                                                                <form class="form-search">
                                                                    <span class="input-icon">
                                                                        <input type="text" autocomplete="off" class="input-small nav-search-input" placeholder="Search inbox ..." />
                                                                        <i class="ace-icon fa fa-search nav-search-icon"></i>
                                                                    </span>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div id="id-message-item-navbar" class="hide message-navbar clearfix">
                                                        <div class="message-bar">
                                                            <div class="message-toolbar">
                                                                <div class="inline position-relative align-left">
                                                                    <button type="button" class="btn-white btn-primary btn btn-xs dropdown-toggle" data-toggle="dropdown">
                                                                        <span class="bigger-110">Action</span>
                                                                        <i class="ace-icon fa fa-caret-down icon-on-right"></i>
                                                                    </button>
                                                                    <ul class="dropdown-menu dropdown-lighter dropdown-caret dropdown-125">
                                                                        <li><a href="#"><i class="ace-icon fa fa-mail-reply blue"></i>&nbsp; Reply</a></li>
                                                                        <li><a href="#"><i class="ace-icon fa fa-mail-forward green"></i>&nbsp; Forward</a></li>
                                                                        <li><a href="#"><i class="ace-icon fa fa-folder-open orange"></i>&nbsp; Archive</a></li>
                                                                        <li class="divider"></li>
                                                                        <li><a href="#"><i class="ace-icon fa fa-eye blue"></i>&nbsp; Mark as read</a></li>
                                                                        <li><a href="#"><i class="ace-icon fa fa-eye-slash green"></i>&nbsp; Mark unread</a></li>
                                                                        <li><a href="#"><i class="ace-icon fa fa-flag-o red"></i>&nbsp; Flag</a></li>
                                                                        <li class="divider"></li>
                                                                        <li><a href="#"><i class="ace-icon fa fa-trash-o red bigger-110"></i>&nbsp; Delete</a></li>
                                                                    </ul>
                                                                </div>
                                                                <div class="inline position-relative align-left">
                                                                    <button type="button" class="btn-white btn-primary btn btn-xs dropdown-toggle" data-toggle="dropdown">
                                                                        <i class="ace-icon fa fa-folder-o bigger-110 blue"></i>
                                                                        <span class="bigger-110">Move to</span>
                                                                        <i class="ace-icon fa fa-caret-down icon-on-right"></i>
                                                                    </button>
                                                                    <ul class="dropdown-menu dropdown-lighter dropdown-caret dropdown-125">
                                                                        <li><a href="#"><i class="ace-icon fa fa-stop pink2"></i>&nbsp; Tag#1</a></li>
                                                                        <li><a href="#"><i class="ace-icon fa fa-stop blue"></i>&nbsp; Family</a></li>
                                                                        <li><a href="#"><i class="ace-icon fa fa-stop green"></i>&nbsp; Friends</a></li>
                                                                        <li><a href="#"><i class="ace-icon fa fa-stop grey"></i>&nbsp; Work</a></li>
                                                                    </ul>
                                                                </div>
                                                                <button type="button" class="btn btn-xs btn-white btn-primary">
                                                                    <i class="ace-icon fa fa-trash-o bigger-125 orange"></i>
                                                                    <span class="bigger-110">Delete</span>
                                                                </button>
                                                            </div>
                                                        </div>
                                                        <div>
                                                            <div class="messagebar-item-left">
                                                                <a href="#" class="btn-back-message-list">
                                                                    <i class="ace-icon fa fa-arrow-left blue bigger-110 middle"></i>
                                                                    <b class="bigger-110 middle">Back</b>
                                                                </a>
                                                            </div>
                                                            <div class="messagebar-item-right">
                                                              <i class="ace-icon fa fa-clock-o bigger-110"></i>
                                                                <span class="bigger-110">Date</span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="message-list-container">
                                                        <div class="message-item" id="message-item-1">
                                                            <label class="inline middle">
                                                                <input type="checkbox" class="ace" />
                                                                <span class="lbl"></span>
                                                            </label>
                                                            <a href="#">
                                                                <img class="message-user-photo" src="assets/images/avatars/user1.jpg" alt="User Photo" />
                                                                <span class="sender">John Doe</span>
                                                                <span class="subject">Subject of the message...</span>
                                                                <span class="message-date">12:30 PM</span>
                                                                <span class="message-preview">&nbsp; Preview of the message content...</span>
                                                            </a>
                                                        </div>

                                                        <div class="message-item" id="message-item-2">
                                                            <label class="inline middle">
                                                                <input type="checkbox" class="ace" />
                                                                <span class="lbl"></span>
                                                            </label>
                                                            <a href="#">
                                                                <img class="message-user-photo" src="assets/images/avatars/user2.jpg" alt="User Photo" />
                                                                <span class="sender">Jane Smith</span>
                                                                <span class="subject">Subject of another message...</span>
                                                                <span class="message-date">1:45 PM</span>
                                                                <span class="message-preview">&nbsp; Another preview of message content...</span>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div id="sent" class="tab-pane">
                                                <div class="message-container">
                                                    <p>No sent messages.</p>
                                                </div>
                                            </div>

                                            <div id="draft" class="tab-pane">
                                                <div class="message-container">
                                                    <p>No draft messages.</p>
                                                </div>
                                            </div>

                                            <div id="write" class="tab-pane">
                                                <div class="message-container">
                                                    <h4>Compose a new message</h4>
                                                    <form action="send_message.php" method="post">
                                                        <div class="form-group">
                                                            <label for="recipient">To:</label>
                                                            <input type="text" class="form-control" id="recipient" name="recipient" required>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="subject">Subject:</label>
                                                            <input type="text" class="form-control" id="subject" name="subject" required>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="message">Message:</label>
                                                            <textarea class="form-control" id="message" name="message" rows="5" required></textarea>
                                                        </div>
                                                        <button type="submit" class="btn btn-primary">Send</button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div><!-- /.tabbable -->
                                </div>
                            </div>
                        </div>
                    </div><!-- /.row -->
                </div><!-- /.page-content -->
            </div><!-- /.main-content-inner -->
        </div><!-- /.main-content -->

        <footer class="footer text-muted">
            <div class="container">
                <span class="text-muted">© 2023 Your Company</span>
            </div>
        </footer>
    </div><!-- /.main-container -->

    <!-- basic scripts -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/ace.min.js"></script>

</body>
</html>