<?php
header('Content-Type: application/json');
$conn = new mysqli("localhost","root","","email_app");
if($conn->connect_error) die(json_encode(['success'=>false,'message'=>'DB Error']));

$message_id = $_POST['message_id'];
$action = $_POST['action'];
$user_id = 1; // logged-in user

// Map simple actions to DB updates
switch($action){
    case 'mark_read':
        $conn->query("UPDATE message_status SET is_read=1 WHERE message_id=$message_id AND user_id=$user_id");
        break;
    case 'mark_unread':
        $conn->query("UPDATE message_status SET is_read=0 WHERE message_id=$message_id AND user_id=$user_id");
        break;
    case 'archive':
        $conn->query("UPDATE message_status SET is_archived=1 WHERE message_id=$message_id AND user_id=$user_id");
        break;
    case 'delete':
        $conn->query("UPDATE message_status SET is_deleted=1 WHERE message_id=$message_id AND user_id=$user_id");
        break;
    case 'flag':
    case 'reply':
    case 'forward':
        // Log action for audit (or redirect to compose)
        $stmt = $conn->prepare("INSERT INTO message_actions (message_id,user_id,action) VALUES (?,?,?)");
        $stmt->bind_param("iis",$message_id,$user_id,$action);
        $stmt->execute();
        break;
    default:
        echo json_encode(['success'=>false,'message'=>'Unknown action']);
        exit;
}

echo json_encode(['success'=>true,'message'=>'Action performed successfully']);
?>