<?php
header('Content-Type: application/json');

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "email_app";

$conn = new mysqli($servername, $username, $password, $dbname);
$conn->set_charset("utf8");

if ($conn->connect_error) {
    die(json_encode(['success'=>false,'message'=>'DB connection failed']));
}

$action = $_POST['action'] ?? 'save';
$tag_id = $_POST['tag_id'] ?? null;
$name = $_POST['name'] ?? null;
$color = $_POST['color'] ?? null;

$current_user_id = 1;

if($action == 'delete' && $tag_id){
    $stmt = $conn->prepare("DELETE FROM tags WHERE id=? AND created_by=?");
    $stmt->bind_param('ii', $tag_id, $current_user_id);
    $stmt->execute();
    echo json_encode(['success'=>true, 'message'=>'Tag deleted']);
    exit;
}

if($name && $color){
    if($tag_id){ // update
        $stmt = $conn->prepare("UPDATE tags SET name=?, color=? WHERE id=? AND created_by=?");
        $stmt->bind_param('ssii', $name, $color, $tag_id, $current_user_id);
        $stmt->execute();
        echo json_encode(['success'=>true, 'message'=>'Tag updated']);
    } else { // create
        $stmt = $conn->prepare("INSERT INTO tags (name,color,created_by) VALUES (?,?,?)");
        $stmt->bind_param('ssi', $name, $color, $current_user_id);
        $stmt->execute();
        echo json_encode(['success'=>true, 'message'=>'Tag created']);
    }
} else {
    echo json_encode(['success'=>false, 'message'=>'Invalid data']);
}
?>