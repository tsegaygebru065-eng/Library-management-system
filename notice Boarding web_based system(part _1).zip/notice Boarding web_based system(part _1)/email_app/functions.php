<?php
$host = 'localhost'; // Your database host
$db = 'email_app'; // Your database name
$user = 'root'; // Your database username
$pass = ''; // Your database password

// Database connection using PDO
try {
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Could not connect to the database: " . $e->getMessage());
}
function getMessages($userId) {
    global $pdo; // Use the PDO connection
    $sql = "SELECT m.*, u.username AS sender_name FROM messages m 
            JOIN users u ON m.sender_id = u.id 
            WHERE m.receiver_id = :userId ORDER BY m.created_at DESC";
    
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':userId', $userId, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC); 
}

function getUser($userId) {
    global $pdo; // Use the PDO connection
    $sql = "SELECT * FROM users WHERE id = :userId"; 
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':userId', $userId, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetch(PDO::FETCH_ASSOC); 
}
?>