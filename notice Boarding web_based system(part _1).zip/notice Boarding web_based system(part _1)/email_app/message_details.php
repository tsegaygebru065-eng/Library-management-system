<?php
// message_details.php

$host = 'localhost'; // Your database host
$db = 'email_app'; // Your database name
$user = 'root'; // Your database username
$pass = ''; // Your database password
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    throw new \PDOException($e->getMessage(), (int)$e->getCode());
}

if (isset($_POST['id'])) {
    $stmt = $pdo->prepare('SELECT m.*, u.username AS sender_name FROM messages m JOIN users u ON m.sender_id = u.id WHERE m.id = ?');
    $stmt->execute([$_POST['id']]);
    $message = $stmt->fetch();

    if ($message) {
        // Mark as read
        $updateStmt = $pdo->prepare('UPDATE messages SET is_read = 1 WHERE id = ?');
        $updateStmt->execute([$message['id']]);

        echo '<h4>' . htmlspecialchars($message['subject']) . '</h4>';
        echo '<p><strong>From:</strong> ' . htmlspecialchars($message['sender_name']) . '</p>';
        echo '<p><strong>Date:</strong> ' . htmlspecialchars($message['created_at']) . '</p>';
        echo '<p>' . nl2br(htmlspecialchars($message['body'])) . '</p>';
    } else {
        echo 'Message not found.';
    }
} else {
    echo 'Invalid request.';
}
?>