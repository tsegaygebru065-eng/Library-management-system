<?php
// db.php - Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "email_app";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
$conn->set_charset("utf8");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Current user ID
$current_user_id = 1;

// Fetch Inbox messages
$inbox_result = $conn->query("
    SELECT m.id, u.name AS sender, m.subject, m.body, ms.is_read, ms.is_starred, ms.updated_at
    FROM messages m
    JOIN message_status ms ON m.id = ms.message_id
    JOIN users u ON m.sender_id = u.id
    WHERE ms.user_id = {$current_user_id} AND ms.folder = 'inbox'
    ORDER BY m.created_at DESC
");

// Fetch Sent messages
$sent_result = $conn->query("
    SELECT m.id, GROUP_CONCAT(u.email) AS recipient, m.subject, m.body, ms.updated_at
    FROM messages m
    JOIN message_status ms ON m.id = ms.message_id
    JOIN message_recipients mr ON m.id = mr.message_id
    JOIN users u ON mr.user_id = u.id
    WHERE ms.user_id = {$current_user_id} AND ms.folder = 'sent'
    GROUP BY m.id
    ORDER BY m.created_at DESC
");

// Fetch Draft messages
$draft_result = $conn->query("
    SELECT m.id, GROUP_CONCAT(u.email) AS recipient, m.subject, m.body, ms.updated_at
    FROM messages m
    JOIN message_status ms ON m.id = ms.message_id
    JOIN message_recipients mr ON m.id = mr.message_id
    JOIN users u ON mr.user_id = u.id
    WHERE ms.user_id = {$current_user_id} AND ms.folder = 'draft'
    GROUP BY m.id
    ORDER BY m.created_at DESC
");
// Fetch Tags
$tags_result = $conn->query("SELECT * FROM tags ORDER BY name ASC");
$tags = [];
if ($tags_result->num_rows > 0) {
    while ($tag = $tags_result->fetch_assoc()) {
        $tags[] = $tag;
    }
}
$user_id = 1; // logged-in user
$message_id = $_GET['message_id'] ?? 1;

// Fetch available actions from message_actions table
$actions_result = $conn->query("SELECT action FROM message_actions WHERE message_id = $message_id");

$actions = [];
if($actions_result->num_rows > 0){
    while($a = $actions_result->fetch_assoc()){
        $actions[] = $a['action'];
    }
}

// Default actions if none exist
if(empty($actions)){
    $actions = ['reply','forward','archive','mark_read','mark_unread','flag','delete'];
}

// Mapping icons/colors
$action_icons = [
    'reply' => ['icon'=>'fa-mail-reply','color'=>'blue','label'=>'Reply'],
    'forward' => ['icon'=>'fa-mail-forward','color'=>'green','label'=>'Forward'],
    'archive' => ['icon'=>'fa-folder-open','color'=>'orange','label'=>'Archive'],
    'mark_read' => ['icon'=>'fa-eye','color'=>'blue','label'=>'Mark as read'],
    'mark_unread' => ['icon'=>'fa-eye-slash','color'=>'green','label'=>'Mark unread'],
    'flag' => ['icon'=>'fa-flag-o','color'=>'red','label'=>'Flag'],
    'delete' => ['icon'=>'fa-trash-o','color'=>'red','label'=>'Delete'],
];

$tags_result = $conn->query("SELECT * FROM tags WHERE created_by=$user_id");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Inbox - Ace Admin</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/font-awesome/4.5.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/ace.min.css">
    <link rel="stylesheet" href="assets/css/ace-skins.min.css">
</head>
<body class="no-skin">
<div id="navbar" class="navbar navbar-default ace-save-state">
    <!-- Navbar content -->
</div>

<div class="main-container ace-save-state" id="main-container">
    <div id="sidebar" class="sidebar responsive ace-save-state">
        <!-- Sidebar content -->
		 
    </div>

    <div class="main-content">
        <div class="main-content-inner">
            <div class="breadcrumbs ace-save-state">
                <ul class="breadcrumb">
                    <li><i class="ace-icon fa fa-home home-icon"></i><a href="#">Home</a></li>
                    <li><a href="#">More Pages</a></li>
                    <li class="active">Inbox</li>
                </ul>
            </div>

            <div class="page-content">
                <div class="page-header">
                    <h1>Inbox <small><i class="ace-icon fa fa-angle-double-right"></i> Mailbox</small></h1>
                </div>

                <div class="row">
                    <div class="col-xs-12">
                        <div class="tabbable">
                            <ul id="inbox-tabs" class="inbox-tabs nav nav-tabs padding-16 tab-size-bigger tab-space-1">
                                <li class="li-new-mail pull-right">
                                    <a data-toggle="tab" href="#write">
                                        <span class="btn btn-purple no-border">
                                            <i class="ace-icon fa fa-envelope bigger-130"></i>
                                            <span class="bigger-110">Write Mail</span>
                                        </span>
                                    </a>
                                </li>
                                <li class="active">
                                    <a data-toggle="tab" href="#inbox"><i class="blue ace-icon fa fa-inbox bigger-130"></i>Inbox</a>
                                </li>
                                <li><a data-toggle="tab" href="#sent"><i class="orange ace-icon fa fa-location-arrow bigger-130"></i>Sent</a></li>
                                <li><a data-toggle="tab" href="#draft"><i class="green ace-icon fa fa-pencil bigger-130"></i>Draft</a></li>
							<li class="dropdown">
    <a data-toggle="dropdown" class="dropdown-toggle" href="#">
        <i class="pink ace-icon fa fa-tags bigger-130"></i>
        <span class="bigger-110">
            Tags
            <i class="ace-icon fa fa-caret-down"></i>
        </span>
    </a>

    <ul class="dropdown-menu dropdown-light-blue dropdown-125">
        <?php if (!empty($tags)): ?>
            <?php foreach ($tags as $tag): ?>
                <li>
                    <a href="#" class="tag-item" data-id="<?php echo $tag['id']; ?>" data-name="<?php echo htmlspecialchars($tag['name']); ?>" data-color="<?php echo $tag['color']; ?>">
                        <span class="mail-tag badge badge-<?php echo $tag['color']; ?>"></span>
                        <span class="<?php echo $tag['color']; ?>"><?php echo htmlspecialchars($tag['name']); ?></span>
                    </a>
                </li>
            <?php endforeach; ?>
        <?php else: ?>
            <li><span class="text-muted">No tags available</span></li>
        <?php endif; ?>
        <li class="divider"></li>
        <li>
            <a href="#" data-toggle="modal" data-target="#tagModal">
                <i class="ace-icon fa fa-plus green"></i> Add New Tag
            </a>
        </li>
    </ul>
</li></ul>
	<div class="tab-content no-border no-padding">
												<div id="inbox" class="tab-pane in active">
													<div class="message-container">
														<div id="id-message-list-navbar" class="message-navbar clearfix">
															<div class="message-bar">
																<div class="message-infobar" id="id-message-infobar">
																	<span class="blue bigger-150">Inbox</span>
																	<span class="grey bigger-110">(2 unread messages)</span>
																</div>

																<div class="message-toolbar hide">
																	<div class="inline position-relative align-left">
    <button type="button" class="btn-white btn-primary btn btn-xs dropdown-toggle" data-toggle="dropdown">
        <span class="bigger-110">Action</span>
        <i class="ace-icon fa fa-caret-down icon-on-right"></i>
    </button>

    <ul class="dropdown-menu dropdown-lighter dropdown-caret dropdown-125">
        <?php foreach($actions as $action): 
            $icon = $action_icons[$action]['icon'] ?? 'fa-circle';
            $color = $action_icons[$action]['color'] ?? 'grey';
            $label = $action_icons[$action]['label'] ?? ucfirst($action);
        ?>
            <li>
                <a href="#" class="message-action" data-action="<?php echo $action; ?>" data-message-id="<?php echo $message_id; ?>">
                    <i class="ace-icon fa <?php echo $icon; ?> <?php echo $color; ?>"></i>&nbsp; <?php echo $label; ?>
                </a>
            </li>
        <?php endforeach; ?>
    </ul>
</div>

																	<div class="inline position-relative align-left">
																		<button type="button" class="btn-white btn-primary btn btn-xs dropdown-toggle" data-toggle="dropdown">
																			<i class="ace-icon fa fa-folder-o bigger-110 blue"></i>
																			<span class="bigger-110">Move to</span>

																			<i class="ace-icon fa fa-caret-down icon-on-right"></i>
																		</button>

																		<ul class="dropdown-menu dropdown-lighter dropdown-caret dropdown-125">
																			<li>
																				<a href="#">
																					<i class="ace-icon fa fa-stop pink2"></i>&nbsp; Tag#1
																				</a>
																			</li>

																			<li>
																				<a href="#">
																					<i class="ace-icon fa fa-stop blue"></i>&nbsp; Family
																				</a>
																			</li>

																			<li>
																				<a href="#">
																					<i class="ace-icon fa fa-stop green"></i>&nbsp; Friends
																				</a>
																			</li>

																			<li>
																				<a href="#">
																					<i class="ace-icon fa fa-stop grey"></i>&nbsp; Work
																				</a>
																			</li>
																		</ul>
																	</div>

																	<button type="button" class="btn btn-xs btn-white btn-primary">
																		<i class="ace-icon fa fa-trash-o bigger-125 orange"></i>
																		<span class="bigger-110">Delete</span>
																	</button>
																</div>
															</div>

															<div>
																<div class="messagebar-item-left">
																	<label class="inline middle">
																		<input type="checkbox" id="id-toggle-all" class="ace" />
																		<span class="lbl"></span>
																	</label>

																	&nbsp;
																	<div class="inline position-relative">
																		<a href="#" data-toggle="dropdown" class="dropdown-toggle">
																			<i class="ace-icon fa fa-caret-down bigger-125 middle"></i>
																		</a>

																		<ul class="dropdown-menu dropdown-lighter dropdown-100">
																			<li>
																				<a id="id-select-message-all" href="#">All</a>
																			</li>

																			<li>
																				<a id="id-select-message-none" href="#">None</a>
																			</li>

																			<li class="divider"></li>

																			<li>
																				<a id="id-select-message-unread" href="#">Unread</a>
																			</li>

																			<li>
																				<a id="id-select-message-read" href="#">Read</a>
																			</li>
																		</ul>
																	</div>
																</div>

																<div class="messagebar-item-right">
																	<div class="inline position-relative">
																		<a href="#" data-toggle="dropdown" class="dropdown-toggle">
																			Sort &nbsp;
																			<i class="ace-icon fa fa-caret-down bigger-125"></i>
																		</a>

																		<ul class="dropdown-menu dropdown-lighter dropdown-menu-right dropdown-100">
																			<li>
																				<a href="#">
																					<i class="ace-icon fa fa-check green"></i>
																					Date
																				</a>
																			</li>

																			<li>
																				<a href="#">
																					<i class="ace-icon fa fa-check invisible"></i>
																					From
																				</a>
																			</li>

																			<li>
																				<a href="#">
																					<i class="ace-icon fa fa-check invisible"></i>
																					Subject
																				</a>
																			</li>
																		</ul>
																	</div>
																</div>

																<div class="nav-search minimized">
																	<form class="form-search">
																		<span class="input-icon">
																			<input type="text" autocomplete="off" class="input-small nav-search-input" placeholder="Search inbox ..." />
																			<i class="ace-icon fa fa-search nav-search-icon"></i>
																		</span>
																	</form>
																</div>
															</div>
														</div>

														<div id="id-message-item-navbar" class="hide message-navbar clearfix">
															<div class="message-bar">
																<div class="message-toolbar">
																	<div class="inline position-relative align-left">
																		<button type="button" class="btn-white btn-primary btn btn-xs dropdown-toggle" data-toggle="dropdown">
																			<span class="bigger-110">Action</span>

																			<i class="ace-icon fa fa-caret-down icon-on-right"></i>
																		</button>

																		<ul class="dropdown-menu dropdown-lighter dropdown-caret dropdown-125">
																			<li>
																				<a href="#">
																					<i class="ace-icon fa fa-mail-reply blue"></i>&nbsp; Reply
																				</a>
																			</li>

																			<li>
																				<a href="#">
																					<i class="ace-icon fa fa-mail-forward green"></i>&nbsp; Forward
																				</a>
																			</li>

																			<li>
																				<a href="#">
																					<i class="ace-icon fa fa-folder-open orange"></i>&nbsp; Archive
																				</a>
																			</li>

																			<li class="divider"></li>

																			<li>
																				<a href="#">
																					<i class="ace-icon fa fa-eye blue"></i>&nbsp; Mark as read
																				</a>
																			</li>

																			<li>
																				<a href="#">
																					<i class="ace-icon fa fa-eye-slash green"></i>&nbsp; Mark unread
																				</a>
																			</li>

																			<li>
																				<a href="#">
																					<i class="ace-icon fa fa-flag-o red"></i>&nbsp; Flag
																				</a>
																			</li>

																			<li class="divider"></li>

																			<li>
																				<a href="#">
																					<i class="ace-icon fa fa-trash-o red bigger-110"></i>&nbsp; Delete
																				</a>
																			</li>
																		</ul>
																	</div>
<?php
// Assume $message_id and $user_id are available
$user_id = 1; // logged-in user for example

// Folders
$folders = [
    'inbox' => 'Inbox',
    'sent' => 'Sent',
    'draft' => 'Draft'
];

// Fetch tags created by the user
$tags_result = $conn->query("SELECT id, name, color FROM tags WHERE created_by = $user_id ORDER BY name ASC");
$tags = [];
while($row = $tags_result->fetch_assoc()){
    $tags[] = $row;
}
?>

<div class="inline position-relative align-left">
    <button type="button" class="btn-white btn-primary btn btn-xs dropdown-toggle" data-toggle="dropdown">
        <i class="ace-icon fa fa-folder-o bigger-110 blue"></i>
        <span class="bigger-110">Move to</span>
        <i class="ace-icon fa fa-caret-down icon-on-right"></i>
    </button>

    <ul class="dropdown-menu dropdown-lighter dropdown-caret dropdown-125">
        <?php foreach($folders as $key => $name): ?>
            <li>
                <a href="#" class="move-message" data-message-id="<?php echo $message_id; ?>" data-folder="<?php echo $key; ?>">
                    <i class="ace-icon fa fa-folder <?php echo $key=='inbox'?'pink2':($key=='sent'?'blue':'grey'); ?>"></i>&nbsp; <?php echo $name; ?>
                </a>
            </li>
        <?php endforeach; ?>

        <?php if(!empty($tags)): ?>
            <li class="divider"></li>
            <?php foreach($tags as $tag): ?>
                <li>
                    <a href="#" class="move-message" data-message-id="<?php echo $message_id; ?>" data-tag-id="<?php echo $tag['id']; ?>">
                        <i class="ace-icon fa fa-stop <?php echo $tag['color']; ?>"></i>&nbsp; <?php echo htmlspecialchars($tag['name']); ?>
                    </a>
                </li>
            <?php endforeach; ?>
        <?php endif; ?>
    </ul>
</div>
																	<button type="button" class="btn btn-xs btn-white btn-primary">
																		<i class="ace-icon fa fa-trash-o bigger-125 orange"></i>
																		<span class="bigger-110">Delete</span>
																	</button>
																</div>
															</div>

															<div>
																<div class="messagebar-item-left">
																	<a href="#" class="btn-back-message-list">
																		<i class="ace-icon fa fa-arrow-left blue bigger-110 middle"></i>
																		<b class="bigger-110 middle">Back</b>
																	</a>
																</div>

																<div class="messagebar-item-right">
																	<i class="ace-icon fa fa-clock-o bigger-110 orange"></i>
																	<span class="grey">Today, 7:15 pm</span>
																</div>
															</div>
														</div>
  

	                                                </div>
												</div>
											</div><!-- /.tab-content -->
										
                            <div class="tab-content no-border no-padding">
                                <!-- Inbox Tab -->
                                <div id="inbox" class="tab-pane in active">
                                    <div class="message-container">
                                        <div class="message-list-container">
                                            <div class="message-list" id="message-list">
                                                <?php if($inbox_result->num_rows > 0): ?>
                                                    <?php while($row = $inbox_result->fetch_assoc()): ?>
                                                        <div class="message-item <?php echo ($row['is_read'] ? '' : 'message-unread'); ?>">
                                                            <label class="inline">
                                                                <input type="checkbox" class="ace" />
                                                                <span class="lbl"></span>
                                                            </label>

                                                            <i class="message-star ace-icon fa <?php echo ($row['is_starred'] ? 'fa-star orange2' : 'fa-star-o grey'); ?>"></i>
                                                            <span class="sender" title="<?php echo $row['sender']; ?>"><?php echo $row['sender']; ?></span>
                                                            <span class="time"><?php echo date("g:i a", strtotime($row['updated_at'])); ?></span>

                                                            <span class="summary"><span class="text"><?php echo $row['subject']; ?></span></span>

                                                            <div class="message-content hide">
                                                                <div class="message-header clearfix">
                                                                    <div class="pull-left">
                                                                        <span class="blue bigger-125"><?php echo $row['subject']; ?></span>
                                                                        <div class="space-4"></div>
                                                                        <img class="middle" src="assets/images/avatars/user.jpg" width="32" />
                                                                        <a href="#" class="sender"><?php echo $row['sender']; ?></a>
                                                                        <span class="time grey"><?php echo date("M d, Y g:i a", strtotime($row['updated_at'])); ?></span>
                                                                    </div>
                                                                </div>
                                                                <div class="hr hr-double"></div>
                                                                <div class="message-body">
                                                                    <p><?php echo nl2br($row['body']); ?></p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php endwhile; ?>
                                                <?php else: ?>
                                                    <div class="alert alert-info">No messages found.</div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Sent Tab  -->
                                <div id="sent" class="tab-pane">
                                    <div class="message-list">
                                        <?php if($sent_result->num_rows > 0): ?>
                                            <?php while($row = $sent_result->fetch_assoc()): ?>
                                                <div class="message-item message-read">
                                                    <span class="sender"><?php echo $row['recipient']; ?></span>
                                                    <span class="time"><?php echo date("g:i a", strtotime($row['updated_at'])); ?></span>
                                                    <span class="summary"><span class="text"><?php echo $row['subject']; ?></span></span>
                                                </div>
                                            <?php endwhile; ?>
                                        <?php else: ?>
                                            <div class="alert alert-info">No sent messages.</div>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <!-- Draft Tab -->
                                <div id="draft" class="tab-pane">
                                    <div class="message-list">
                                        <?php if($draft_result->num_rows > 0): ?>
                                            <?php while($row = $draft_result->fetch_assoc()): ?>
                                                <div class="message-item message-read">
                                                    <span class="sender"><?php echo $row['recipient']; ?></span>
                                                    <span class="time"><?php echo date("g:i a", strtotime($row['updated_at'])); ?></span>
                                                    <span class="summary"><span class="text"><?php echo $row['subject']; ?></span></span>
                                                </div>
                                            <?php endwhile; ?>
                                        <?php else: ?>
                                            <div class="alert alert-info">No drafts.</div>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <!-- Write Tab -->
                                <div id="write" class="tab-pane">
                                    <form class="form-horizontal message-form col-xs-12" method="post" action="send_mail.php">
                                        <div class="form-group">
                                            <label class="col-sm-3 control-label no-padding-right" for="recipient">Recipient:</label>
                                            <div class="col-sm-9">
                                                <input type="email" name="recipient" class="form-control" placeholder="Recipient">
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label class="col-sm-3 control-label no-padding-right" for="subject">Subject:</label>
                                            <div class="col-sm-9">
                                                <input type="text" name="subject" class="form-control" placeholder="Subject">
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label class="col-sm-3 control-label no-padding-right">Message:</label>
                                            <div class="col-sm-9">
                                                <textarea class="form-control" name="message" rows="6" placeholder="Write your message here..."></textarea>
                                            </div>
                                        </div>

                                        <div class="form-group no-margin-bottom">
                                            <div class="col-sm-9 col-sm-offset-3">
                                                <button type="submit" class="btn btn-primary">Send</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>

                            </div><!-- /.tab-content -->
                        </div><!-- /.tabbable -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
 <!-- Tag Modal -->
<div class="modal fade" id="tagModal" tabindex="-1" role="dialog" aria-labelledby="tagModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <form id="tagForm">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="tagModalLabel">Add / Edit Tag</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <input type="hidden" name="tag_id" id="tag_id">
          <div class="form-group">
            <label for="tag_name">Tag Name</label>
            <input type="text" class="form-control" id="tag_name" name="name" required>
          </div>
          <div class="form-group">
            <label for="tag_color">Color</label>
            <select class="form-control" id="tag_color" name="color" required>
              <option value="pink">Pink</option>
              <option value="green">Green</option>
              <option value="blue">Blue</option>
              <option value="grey">Grey</option>
              <option value="orange">Orange</option>
            </select>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" id="deleteTag" class="btn btn-danger" style="display:none;">Delete</button>
          <button type="submit" class="btn btn-primary">Save Tag</button>
        </div>
      </div>
    </form>
  </div>
</div>

<script src="assets/js/jquery-2.1.4.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/ace-elements.min.js"></script>
<script src="assets/js/ace.min.js"></script>
<script>
jQuery(function($){
    $(document).on('click', '.move-message', function(e){
        e.preventDefault();
        let messageId = $(this).data('message-id');
        let folder = $(this).data('folder') || null;
        let tagId = $(this).data('tag-id') || null;

        $.post('move_message.php', {message_id: messageId, folder: folder, tag_id: tagId}, function(res){
            if(res.success) location.reload();
            else alert(res.message);
        }, 'json');
    });
});
</script>

<script>
jQuery(function($){
    $(document).on('click', '.message-action', function(e){
        e.preventDefault();
        let messageId = $(this).data('message-id');
        let action = $(this).data('action');

        $.post('message_action_crud.php', {message_id: messageId, action: action}, function(response){
            alert(response.message);
            if(response.success){
                // Optionally reload or update UI
                location.reload();
            }
        }, 'json');
    });
});
</script>
<script>
$(document).ready(function(){
    $(".message-item").click(function(){
        $(this).find(".message-content").slideToggle();
        var id=$(this).data("id");
        if(id) $.post("", {mark_read:1, message_id:id});
    });
    $(".message-star").click(function(e){
        e.stopPropagation();
        var $this=$(this),id=$(this).closest(".message-item").data("id"),star=$this.hasClass("fa-star");
        $.post("", {toggle_star:1, message_id:id, star:star}, function(){ 
            $this.toggleClass("fa-star fa-star-o");
        });
    });
});
</script>
<script>
$(document).ready(function(){

    // Open modal for editing
    $('.tag-item').on('click', function(){
        let id = $(this).data('id');
        let name = $(this).data('name');
        let color = $(this).data('color');

        $('#tag_id').val(id);
        $('#tag_name').val(name);
        $('#tag_color').val(color);
        $('#deleteTag').show();
        $('#tagModal').modal('show');
    });

    // Add new tag modal
    $('[data-target="#tagModal"]').on('click', function(){
        $('#tagForm')[0].reset();
        $('#tag_id').val('');
        $('#deleteTag').hide();
    });

    // Save (Add/Edit) Tag
    $('#tagForm').on('submit', function(e){
        e.preventDefault();
        $.post('tag_crud.php', $(this).serialize(), function(response){
            alert(response.message);
            if(response.success) location.reload();
        }, 'json');
    });

    // Delete Tag
    $('#deleteTag').on('click', function(){
        if(confirm('Are you sure you want to delete this tag?')){
            $.post('tag_crud.php', {action:'delete', tag_id: $('#tag_id').val()}, function(response){
                alert(response.message);
                if(response.success) location.reload();
            }, 'json');
        }
    });

});
</script>
	<script type="text/javascript">
	
			jQuery(function($){
			
				//handling tabs and loading/displaying relevant messages and forms
				//not needed if using the alternative view, as described in docs
				$('#inbox-tabs a[data-toggle="tab"]').on('show.bs.tab', function (e) {
					var currentTab = $(e.target).data('target');
					if(currentTab == 'write') {
						Inbox.show_form();
					}
					else if(currentTab == 'inbox') {
						Inbox.show_list();
					}
				})
			
			
				
				//basic initializations
				$('.message-list .message-item input[type=checkbox]').removeAttr('checked');
				$('.message-list').on('click', '.message-item input[type=checkbox]' , function() {
					$(this).closest('.message-item').toggleClass('selected');
					if(this.checked) Inbox.display_bar(1);//display action toolbar when a message is selected
					else {
						Inbox.display_bar($('.message-list input[type=checkbox]:checked').length);
						//determine number of selected messages and display/hide action toolbar accordingly
					}		
				});
			
			
				//check/uncheck all messages
				$('#id-toggle-all').removeAttr('checked').on('click', function(){
					if(this.checked) {
						Inbox.select_all();
					} else Inbox.select_none();
				});
				
				//select all
				$('#id-select-message-all').on('click', function(e) {
					e.preventDefault();
					Inbox.select_all();
				});
				
				//select none
				$('#id-select-message-none').on('click', function(e) {
					e.preventDefault();
					Inbox.select_none();
				});
				
				//select read
				$('#id-select-message-read').on('click', function(e) {
					e.preventDefault();
					Inbox.select_read();
				});
			
				//select unread
				$('#id-select-message-unread').on('click', function(e) {
					e.preventDefault();
					Inbox.select_unread();
				});
			
				/////////
			
				//display first message in a new area
				$('.message-list .message-item:eq(0) .text').on('click', function() {
					//show the loading icon
					$('.message-container').append('<div class="message-loading-overlay"><i class="fa-spin ace-icon fa fa-spinner orange2 bigger-160"></i></div>');
					
					$('.message-inline-open').removeClass('message-inline-open').find('.message-content').remove();
			
					var message_list = $(this).closest('.message-list');
			
					$('#inbox-tabs a[href="#inbox"]').parent().removeClass('active');
					//some waiting
					setTimeout(function() {
			
						//hide everything that is after .message-list (which is either .message-content or .message-form)
						message_list.next().addClass('hide');
						$('.message-container').find('.message-loading-overlay').remove();
			
						//close and remove the inline opened message if any!
			
						//hide all navbars
						$('.message-navbar').addClass('hide');
						//now show the navbar for single message item
						$('#id-message-item-navbar').removeClass('hide');
			
						//hide all footers
						$('.message-footer').addClass('hide');
						//now show the alternative footer
						$('.message-footer-style2').removeClass('hide');
						
						
						//move .message-content next to .message-list and hide .message-list
						$('.message-content').removeClass('hide').insertAfter(message_list.addClass('hide'));
			
						//add scrollbars to .message-body
						$('.message-content .message-body').ace_scroll({
							size: 150,
							mouseWheelLock: true,
							styleClass: 'scroll-visible'
						});
			
					}, 500 + parseInt(Math.random() * 500));
				});
			
			
				//display second message right inside the message list
				$('.message-list .message-item:eq(1) .text').on('click', function(){
					var message = $(this).closest('.message-item');
			
					//if message is open, then close it
					if(message.hasClass('message-inline-open')) {
						message.removeClass('message-inline-open').find('.message-content').remove();
						return;
					}
			
					$('.message-container').append('<div class="message-loading-overlay"><i class="fa-spin ace-icon fa fa-spinner orange2 bigger-160"></i></div>');
					setTimeout(function() {
						$('.message-container').find('.message-loading-overlay').remove();
						message
							.addClass('message-inline-open')
							.append('<div class="message-content" />')
						var content = message.find('.message-content:last').html( $('#id-message-content').html() );
			
						//remove scrollbar elements
						content.find('.scroll-track').remove();
						content.find('.scroll-content').children().unwrap();
						
						content.find('.message-body').ace_scroll({
							size: 150,
							mouseWheelLock: true,
							styleClass: 'scroll-visible'
						});
				
					}, 500 + parseInt(Math.random() * 500));
					
				});
			
			
			
				//back to message list
				$('.btn-back-message-list').on('click', function(e) {
					
					e.preventDefault();
					$('#inbox-tabs a[href="#inbox"]').tab('show');
				});
			
			
			
				//hide message list and display new message form
				/**
				$('.btn-new-mail').on('click', function(e){
					e.preventDefault();
					Inbox.show_form();
				});
				*/
			
			
			
			
				var Inbox = {
					//displays a toolbar according to the number of selected messages
					display_bar : function (count) {
						if(count == 0) {
							$('#id-toggle-all').removeAttr('checked');
							$('#id-message-list-navbar .message-toolbar').addClass('hide');
							$('#id-message-list-navbar .message-infobar').removeClass('hide');
						}
						else {
							$('#id-message-list-navbar .message-infobar').addClass('hide');
							$('#id-message-list-navbar .message-toolbar').removeClass('hide');
						}
					}
					,
					select_all : function() {
						var count = 0;
						$('.message-item input[type=checkbox]').each(function(){
							this.checked = true;
							$(this).closest('.message-item').addClass('selected');
							count++;
						});
						
						$('#id-toggle-all').get(0).checked = true;
						
						Inbox.display_bar(count);
					}
					,
					select_none : function() {
						$('.message-item input[type=checkbox]').removeAttr('checked').closest('.message-item').removeClass('selected');
						$('#id-toggle-all').get(0).checked = false;
						
						Inbox.display_bar(0);
					}
					,
					select_read : function() {
						$('.message-unread input[type=checkbox]').removeAttr('checked').closest('.message-item').removeClass('selected');
						
						var count = 0;
						$('.message-item:not(.message-unread) input[type=checkbox]').each(function(){
							this.checked = true;
							$(this).closest('.message-item').addClass('selected');
							count++;
						});
						Inbox.display_bar(count);
					}
					,
					select_unread : function() {
						$('.message-item:not(.message-unread) input[type=checkbox]').removeAttr('checked').closest('.message-item').removeClass('selected');
						
						var count = 0;
						$('.message-unread input[type=checkbox]').each(function(){
							this.checked = true;
							$(this).closest('.message-item').addClass('selected');
							count++;
						});
						
						Inbox.display_bar(count);
					}
				}
			
				//show message list (back from writing mail or reading a message)
				Inbox.show_list = function() {
					$('.message-navbar').addClass('hide');
					$('#id-message-list-navbar').removeClass('hide');
			
					$('.message-footer').addClass('hide');
					$('.message-footer:not(.message-footer-style2)').removeClass('hide');
			
					$('.message-list').removeClass('hide').next().addClass('hide');
					//hide the message item / new message window and go back to list
				}
			
				//show write mail form
				Inbox.show_form = function() {
					if($('.message-form').is(':visible')) return;
					if(!form_initialized) {
						initialize_form();
					}
					
					
					var message = $('.message-list');
					$('.message-container').append('<div class="message-loading-overlay"><i class="fa-spin ace-icon fa fa-spinner orange2 bigger-160"></i></div>');
					
					setTimeout(function() {
						message.next().addClass('hide');
						
						$('.message-container').find('.message-loading-overlay').remove();
						
						$('.message-list').addClass('hide');
						$('.message-footer').addClass('hide');
						$('.message-form').removeClass('hide').insertAfter('.message-list');
						
						$('.message-navbar').addClass('hide');
						$('#id-message-new-navbar').removeClass('hide');
						
						
						//reset form??
						$('.message-form .wysiwyg-editor').empty();
					
						$('.message-form .ace-file-input').closest('.file-input-container:not(:first-child)').remove();
						$('.message-form input[type=file]').ace_file_input('reset_input');
						
						$('.message-form').get(0).reset();
						
					}, 300 + parseInt(Math.random() * 300));
				}
			
			
			
			
				var form_initialized = false;
				function initialize_form() {
					if(form_initialized) return;
					form_initialized = true;
					
					//intialize wysiwyg editor
					$('.message-form .wysiwyg-editor').ace_wysiwyg({
						toolbar:
						[
							'bold',
							'italic',
							'strikethrough',
							'underline',
							null,
							'justifyleft',
							'justifycenter',
							'justifyright',
							null,
							'createLink',
							'unlink',
							null,
							'undo',
							'redo'
						]
					}).prev().addClass('wysiwyg-style1');
			
			
			
					//file input
					$('.message-form input[type=file]').ace_file_input()
					.closest('.ace-file-input')
					.addClass('width-90 inline')
					.wrap('<div class="form-group file-input-container"><div class="col-sm-7"></div></div>');
			
					//Add Attachment
					//the button to add a new file input
					$('#id-add-attachment')
					.on('click', function(){
						var file = $('<input type="file" name="attachment[]" />').appendTo('#form-attachments');
						file.ace_file_input();
						
						file.closest('.ace-file-input')
						.addClass('width-90 inline')
						.wrap('<div class="form-group file-input-container"><div class="col-sm-7"></div></div>')
						.parent().append('<div class="action-buttons pull-right col-xs-1">\
							<a href="#" data-action="delete" class="middle">\
								<i class="ace-icon fa fa-trash-o red bigger-130 middle"></i>\
							</a>\
						</div>')
						.find('a[data-action=delete]').on('click', function(e){
							//the button that removes the newly inserted file input
							e.preventDefault();
							$(this).closest('.file-input-container').hide(300, function(){ $(this).remove() });
						});
					});
				}//initialize_form
			
				//turn the recipient field into a tag input field!
				/**	
				var tag_input = $('#form-field-recipient');
				try { 
					tag_input.tag({placeholder:tag_input.attr('placeholder')});
				} catch(e) {}
			
			
				//and add form reset functionality
				$('#id-message-form').on('reset', function(){
					$('.message-form .message-body').empty();
					
					$('.message-form .ace-file-input:not(:first-child)').remove();
					$('.message-form input[type=file]').ace_file_input('reset_input_ui');
			
					var val = tag_input.data('value');
					tag_input.parent().find('.tag').remove();
					$(val.split(',')).each(function(k,v){
						tag_input.before('<span class="tag">'+v+'<button class="close" type="button">&times;</button></span>');
					});
				});
				*/
			
			});
		</script>
	
</body>
</html>