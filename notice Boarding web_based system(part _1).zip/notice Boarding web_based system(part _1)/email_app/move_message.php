<?php
header('Content-Type: application/json');
$conn = new mysqli("localhost","root","","email_app");
$user_id = 1; // logged-in user
$message_id = $_POST['message_id'];
$folder = $_POST['folder'] ?? null;
$tag_id = $_POST['tag_id'] ?? null;

if($folder){
    $stmt = $conn->prepare("UPDATE message_status SET folder=? WHERE message_id=? AND user_id=?");
    $stmt->bind_param("sii", $folder, $message_id, $user_id);
    $stmt->execute();
    echo json_encode(['success'=>true,'message'=>'Message moved to '.$folder]);
    exit;
}

if($tag_id){
    // Insert into message_tags if not exists
    $stmt = $conn->prepare("INSERT IGNORE INTO message_tags (message_id, tag_id) VALUES (?,?)");
    $stmt->bind_param("ii", $message_id, $tag_id);
    $stmt->execute();
    echo json_encode(['success'=>true,'message'=>'Message tagged successfully']);
    exit;
}

echo json_encode(['success'=>false,'message'=>'Invalid request']);
?>