-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 16, 2026 at 10:53 AM
-- Server version: 12.0.2-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `user_profile_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `colleges`
--

CREATE TABLE `colleges` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `colleges`
--

INSERT INTO `colleges` (`id`, `name`) VALUES
(1, 'XYZ University'),
(2, 'ABC College'),
(3, 'XYZ Universitydsada'),
(4, 'ABCsdas College');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `college_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `name`, `college_id`) VALUES
(1, 'Computer Science', 1),
(2, 'Electrical Engineering', 1),
(3, 'Business Administration', 2);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `father_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `college_id` int(11) DEFAULT NULL,
  `department_id` int(11) DEFAULT NULL,
  `role` int(11) NOT NULL DEFAULT 0,
  `city` varchar(100) DEFAULT NULL,
  `about` text DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `created_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_by` int(11) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `gender` enum('Male','Female') DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `facebook` varchar(100) DEFAULT NULL,
  `twitter` varchar(100) DEFAULT NULL,
  `google_plus` varchar(100) DEFAULT NULL,
  `last_online` varchar(50) NOT NULL,
  `joined` datetime NOT NULL DEFAULT current_timestamp(),
  `is_public` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Profile visibility: 0 = private, 1 = public',
  `email_updates` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Email updates: 0 = no, 1 = yes',
  `history_enabled` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'History of conversations: 0 = no, 1 = yes',
  `previous_password` varchar(255) DEFAULT NULL COMMENT 'Stores the previously used password hash',
  `new_password` varchar(255) DEFAULT NULL COMMENT 'Stores the new password hash before update'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `first_name`, `father_name`, `last_name`, `email`, `college_id`, `department_id`, `role`, `city`, `about`, `age`, `avatar`, `created_at`, `created_by`, `updated_at`, `updated_by`, `deleted_at`, `deleted_by`, `birth_date`, `gender`, `phone`, `facebook`, `twitter`, `google_plus`, `last_online`, `joined`, `is_public`, `email_updates`, `history_enabled`, `previous_password`, `new_password`) VALUES
(6, 'AKU02332', 'Abadi ', 'Desta', 'Tesfay', 'gfgdfg@gmail.vcom', 1, 2, 1, 'Aksums', 'fghfghfghfg\r\n gfhfghfg \r\nfsdgsgsg', 39, 'uploads/avatars/1773653180_sponsor_logo.PNG', '2026-03-15 11:01:21', NULL, '2026-03-16 09:26:20', NULL, NULL, NULL, '2026-04-25', 'Male', '089098', 'fsdfsdf', 'ttttttttt', 'gggggggggg', '2026-03-15 14:43:58', '2026-03-15 14:14:01', 1, 1, 1, '202cb962ac59075b964b07152d234b70', '$2y$10$7jSdPZyR.xm8hoXbz3OVD.Aq/V5XeD10NWPrK03j3D5ZLLR5WkpTy'),
(8, 'AKU02332', 'Abadi ', 'Desta', 'Tesfay', 'gfgdfg@gmail.vcom', 1, 2, 1, 'Aksums', 'fghfghfghfg\r\n gfhfghfg \r\nfsdgsgsg', 39, 'uploads/avatars/1773653999_slide2.jpg', '2026-03-15 11:01:21', NULL, '2026-03-16 09:39:59', NULL, NULL, NULL, '2026-04-25', 'Male', '089098', 'fsdfsdf', 'ttttttttt', 'gggggggggg', '2026-03-15 14:43:58', '2026-03-15 14:14:01', 1, 1, 1, '202cb962ac59075b964b07152d234b70', '$2y$10$7jSdPZyR.xm8hoXbz3OVD.Aq/V5XeD10NWPrK03j3D5ZLLR5WkpTy');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `colleges`
--
ALTER TABLE `colleges`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `college_id` (`college_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `college_id` (`college_id`),
  ADD KEY `department_id` (`department_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `colleges`
--
ALTER TABLE `colleges`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `departments`
--
ALTER TABLE `departments`
  ADD CONSTRAINT `departments_ibfk_1` FOREIGN KEY (`college_id`) REFERENCES `colleges` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`college_id`) REFERENCES `colleges` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `users_ibfk_2` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
